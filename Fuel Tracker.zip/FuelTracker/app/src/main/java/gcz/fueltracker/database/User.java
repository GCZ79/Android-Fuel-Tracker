package gcz.fueltracker.database;

import androidx.room.Entity;
import androidx.room.PrimaryKey;
import androidx.room.Index;
import androidx.room.Ignore;

// @Entity annotation configures this as a Room database table
@SuppressWarnings("unused")
@Entity(tableName = "users", indices = {@Index(value = {"username"}, unique = true)})
public class User {

    @PrimaryKey(autoGenerate = true)
    private int id;

    private String username;
    private String password;

    private boolean firstLogin;

    // constructor Room uses for entity creation
    public User(String username, String password) {
        this.username = username;
        this.password = password;
        this.firstLogin = true;
    }

    // Used only for session restoration, Room should ignore it
    @Ignore
    public User(String username) {
        this.username = username;
        this.password = null;
        this.firstLogin = false;
    }

    // Getters and setters - Primary key
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    // Username getter/setter
    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    // Password getter/setter
    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }

    // Setter allows updating firstLogin status after initial setup
    public boolean isFirstLogin() { return firstLogin; }
    public void setFirstLogin(boolean firstLogin) { this.firstLogin = firstLogin; }
}
