package gcz.fueltracker.database;

// Import @Dao annotation to mark this as a Data Access Object interface
import androidx.room.Dao;
import androidx.room.Insert; // insert operations
import androidx.room.Delete; // delete operations
import androidx.room.Query;  // custom SQL queries

import java.util.List; // returning collections of FuelRefill objects
@SuppressWarnings("unused")
@Dao // @Dao annotation marks this interface as a Room Data Access Object
public interface FuelRefillDao { // define operations for FuelRefill entity

    @Insert // Room generates SQL INSERT statement
    void insertRefill(FuelRefill refill);

    // Define custom SQL query
    @Query("SELECT * FROM fuel_refill WHERE username = :username ORDER BY timestamp DESC")
    List<FuelRefill> getRefillsForUser(String username);
    // Returns List of all FuelRefill records for a specific user
    // Sorted with most recent refills first

    @Delete // Room generates SQL DELETE statement
    void deleteRefill(FuelRefill refill);

    // Custom query to get the most recent refill
    @Query("SELECT * FROM fuel_refill WHERE username = :username ORDER BY timestamp DESC LIMIT 1")
    FuelRefill getLastRefill(String username);

    // More specific query with two WHERE conditions
    @Query("SELECT * FROM fuel_refill WHERE username = :username AND station = :station ORDER BY timestamp DESC LIMIT 1")
    FuelRefill getLastRefillForUserAndStation(String username, String station);
}