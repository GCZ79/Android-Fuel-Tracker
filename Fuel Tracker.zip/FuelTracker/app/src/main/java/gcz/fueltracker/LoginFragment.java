package gcz.fueltracker;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import gcz.fueltracker.database.AppDatabase;
import gcz.fueltracker.database.DatabaseClient;
import gcz.fueltracker.database.User;
import gcz.fueltracker.database.UserDao;

// Login/Register/Logout fragment - handles user authentication
public class LoginFragment extends Fragment {

    // Callback interface to pass logged-in user back to MainActivity
    public interface LoginCallback {
        void onLoginSuccess(User user); // Called when login succeeds or user logs out
    }

    private LoginCallback loginCallback; // Reference to Activity's callback implementation

    public LoginFragment() {
           // Required empty constructor
        }

    // Setter method for callback
    public void setLoginCallback(LoginCallback callback) {
        this.loginCallback = callback;
    }

    // Lifecycle method - creates the fragment's UI
    @SuppressLint("SetTextI18n")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the XML layout
        View view = inflater.inflate(R.layout.fragment_login, container, false);

        // Local variables for Fragment's lifecycle
        EditText usernameInput = view.findViewById(R.id.username); // Username entry field
        EditText passwordInput = view.findViewById(R.id.password); // Password entry field
        Button loginButton = view.findViewById(R.id.btnLogin); // Login action button
        Button registerButton = view.findViewById(R.id.btnRegister); // Register action button
        Button logoutButton = view.findViewById(R.id.btnLogout); // Logout action button
        TextView welcomeMessage = view.findViewById(R.id.welcomeMessage); // Greeting text
        View loginLayout = view.findViewById(R.id.loginLayout); // Login/register form container
        View logoutLayout = view.findViewById(R.id.logoutLayout); // Logout interface container

        // Get database instance and User DAO for authentication operations
        AppDatabase db = DatabaseClient.getInstance(requireContext());
        UserDao userDao = db.userDao();

        // Check if user is already logged in by asking parent Activity
        MainActivity mainActivity = (MainActivity) requireActivity();
        User currentUser = mainActivity.getCurrentUser();

        // Show appropriate UI based on login state
        if (currentUser != null) { // User is logged in
            loginLayout.setVisibility(View.GONE);  // Hide login form
            logoutLayout.setVisibility(View.VISIBLE); // Show logout panel
            welcomeMessage.setText("Welcome, " + currentUser.getUsername() + "! 👋");
        } else { // No user logged in
            loginLayout.setVisibility(View.VISIBLE); // Show login form
            logoutLayout.setVisibility(View.GONE); // Hide logout panel
        }

        // --- LOGIN BUTTON CLICK LISTENER ---
        loginButton.setOnClickListener(v -> { // Get and clean user input
            String username = usernameInput.getText().toString().trim();
            String password = passwordInput.getText().toString().trim();

            if (username.isEmpty() || password.isEmpty()) { // Basic validation
                Toast.makeText(getContext(), "Please enter username and password", Toast.LENGTH_SHORT).show();
                return; // Stop processing if validation fails
            }

            // Database query running on background thread
            new Thread(() -> {
                // Query database for user with provided username
                User user = userDao.getUserByUsername(username);

                // Switch to UI thread for Toast and UI updates
                requireActivity().runOnUiThread(() -> {
                    // Check if user exists AND password matches
                    if (user != null && user.getPassword().equals(password)) { // Login successful
                        Toast.makeText(getContext(), "Welcome back, " + username + "! 👋", Toast.LENGTH_SHORT).show();

                        // Notify parent Activity about successful login
                        if (loginCallback != null) loginCallback.onLoginSuccess(user);

                        // Update UI to show logout interface
                        loginLayout.setVisibility(View.GONE);
                        logoutLayout.setVisibility(View.VISIBLE);
                        welcomeMessage.setText("Welcome, " + user.getUsername() + "! 👋");

                        // Check if first-time user (for onboarding flow)
                        if (user.isFirstLogin()) {
                            // Update database to mark user as no longer first-time
                            new Thread(() -> {
                                user.setFirstLogin(false);
                                userDao.updateUser(user);
                            }).start(); // Background thread for DB update

                            // Navigate to SettingsFragment for first-time setup
                            Bundle bundle = new Bundle();
                            bundle.putString("username", username); // Pass data via arguments

                            SettingsFragment fragment = new SettingsFragment();
                            fragment.setArguments(bundle);
                            mainActivity.openFragment(fragment); // Use Activity's navigation method

                        } else { // Regular user - go to Fuel Refill page
                            Bundle bundle = new Bundle();
                            bundle.putString("username", username);

                            FuelRefillFragment fragment = new FuelRefillFragment(user);
                            fragment.setArguments(bundle);
                            mainActivity.openFragment(fragment);
                        }

                    } else { // Login failed - incorrect credentials
                        Toast.makeText(getContext(), "Invalid username or password", Toast.LENGTH_SHORT).show();
                    }
                });
            }).start(); // Execute the background thread
        });

        // --- REGISTER BUTTON CLICK LISTENER ---
        registerButton.setOnClickListener(v -> {
            String username = usernameInput.getText().toString().trim();
            String password = passwordInput.getText().toString().trim();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(getContext(), "Please enter username and password", Toast.LENGTH_SHORT).show();
                return;
            }

            // Check if username exists (background thread)
            new Thread(() -> {
                User existing = userDao.getUserByUsername(username);

                // Return to UI thread for result display
                requireActivity().runOnUiThread(() -> {
                    if (existing != null) { // Username already taken
                        Toast.makeText(getContext(), "Username already taken", Toast.LENGTH_SHORT).show();
                    } else { // Username available - create new user in background
                        new Thread(() -> {
                            User newUser = new User(username, password);
                            newUser.setFirstLogin(true); // Mark for first-time onboarding
                            userDao.insertUser(newUser); // Save to database

                            // Notify user on UI thread
                            requireActivity().runOnUiThread(() -> Toast.makeText(getContext(),
                                    "User registered! Please log in.", Toast.LENGTH_SHORT).show());
                        }).start(); // Execute user creation thread
                    }
                });
            }).start(); // Execute username check thread
        });

        // --- LOGOUT BUTTON CLICK LISTENER ---
        logoutButton.setOnClickListener(v -> { // Get reference to parent Activity
            MainActivity activity = (MainActivity) requireActivity();

            // Notify Activity that user logged out (pass null)
            if (loginCallback != null) loginCallback.onLoginSuccess(null);

            Toast.makeText(getContext(), "Logged out successfully", Toast.LENGTH_SHORT).show();

            // Create fresh login fragment (clears any state)
            LoginFragment loginFragment = new LoginFragment();
            loginFragment.setLoginCallback(loginCallback); // Preserve callback reference
            // Replace current fragment with fresh login fragment
            activity.getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.fullPageContainer, loginFragment)
                    .commit(); // prevents navigating back to logged-in state
        });

        return view; // Return the fully configured view to FragmentManager
    }
}
