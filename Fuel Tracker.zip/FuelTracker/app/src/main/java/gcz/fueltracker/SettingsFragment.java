package gcz.fueltracker;

import android.Manifest;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.preference.EditTextPreference;
import androidx.preference.Preference;
import androidx.preference.SwitchPreferenceCompat;
import androidx.preference.PreferenceFragmentCompat;

import android.telephony.SmsManager;

import java.util.Locale;

// Manage app settings/preferences.
public class SettingsFragment extends PreferenceFragmentCompat {

    // Regex pattern for validating phone numbers (10-15 digits)
    private static final String PHONE_NUMBER_PATTERN = "\\d{10,15}"; // Phone number
    private static final String TAG = "SettingsFragment";            // Logging tag

    // Permission launcher using ActivityResultAPI
    private ActivityResultLauncher<String> smsPermissionLauncher;

    // Loads preferences from XML and sets up listeners.
    @Override
    public void onCreatePreferences(Bundle savedInstanceState, String rootKey) {
        // Load preferences from XML resource file
        setPreferencesFromResource(R.xml.preferences, rootKey);

        // Initialize SMS permission launcher with result callback
        smsPermissionLauncher = registerForActivityResult(
                new ActivityResultContracts.RequestPermission(),
                this::handlePermissionResult
        );

        // Setup validation for numeric input fields
        setupEditText("mpg_low_value");
        setupEditText("mpg_high_value");
        setupEditText("alert_phone_number");

        // Setup SMS alert switches with their associated value fields
        setupSwitch("alert_mpg_low", "mpg_low_value", "Low MPG alert: ");
        setupSwitch("alert_mpg_high", "mpg_high_value", "High MPG alert: ");

        // Setup current MPG display
        setupCurrentMPGDisplay();
    }

    // Handle the result of SMS permission request
    private void handlePermissionResult(Boolean isGranted) {
        if (isGranted) {
            showToast("SMS permission granted. You can now enable alerts.");
        } else {
            showToast("Permission denied. Cannot enable SMS alerts.");
        }
    }

    // Customize the appearance by removing default padding/margins
    @Override
    public void onViewCreated(@NonNull android.view.View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Set white background
        view.setBackgroundColor(ContextCompat.getColor(requireContext(), android.R.color.white));

        // Remove padding/margins after layout is complete
        view.post(this::removePaddingAndMargins);
    }

    // Remove all padding and margins from preference list to achieve full-width display
    private void removePaddingAndMargins() {
        // Remove internal padding from RecyclerView
        getListView().setPadding(0, 0, 0, 0);

        // Remove horizontal margins if layout params support them
        ViewGroup.LayoutParams params = getListView().getLayoutParams();
        if (params instanceof ViewGroup.MarginLayoutParams) {
            ViewGroup.MarginLayoutParams marginParams = (ViewGroup.MarginLayoutParams) params;
            marginParams.leftMargin = 0;
            marginParams.rightMargin = 0;
            getListView().setLayoutParams(marginParams);
        }

        // Remove padding from parent container
        ViewGroup parent = (ViewGroup) getListView().getParent();
        if (parent != null) {
            parent.setPadding(0, 0, 0, 0);
        }
    }

    // Setup display of current MPG (last 4 weeks average)
    private void setupCurrentMPGDisplay() { // Find the preference by its key
        Preference mpgDisplay = findPreference("current_mpg_display");
        if (mpgDisplay != null) { // Ensure the preference was successfully found
            updateMPGDisplay(mpgDisplay); // Initialize the display with current MPG value

            // Make it clickable to refresh the value
            mpgDisplay.setOnPreferenceClickListener(preference -> {
                updateMPGDisplay(preference); // When clicked, refresh the MPG value
                showToast("MPG value refreshed"); // Show confirmation message
                return true; // Return true to indicate the click was consumed
            });
        }
    }

    // Update the MPG display with current value from SharedPreferences
    private void updateMPGDisplay(Preference mpgDisplay) {
        // Calculate the current MPG (Miles Per Gallon) for the last 4 weeks
        float currentMPG = MainActivity.getLast4WeeksMPG(requireContext());

        if (currentMPG > 0) { // Successful calculation with sufficient data
            // Format and display the calculated MPG value
            mpgDisplay.setSummary(String.format(Locale.US, "%.1f MPG (last 4 weeks)", currentMPG));
        } else { // Display user-friendly message when data is insufficient
            mpgDisplay.setSummary("No data available - need at least 2 refills");
        }
    }

    // Fragment lifecycle method override
    @Override
    public void onResume() {
        super.onResume(); // Call superclass implementation first (required for proper lifecycle)
        // Refresh MPG display when returning to settings
        Preference mpgDisplay = findPreference("current_mpg_display");
        if (mpgDisplay != null) { // Safety check before updating
            updateMPGDisplay(mpgDisplay); // Update the display with fresh data
        }
    }

    // Handle phone number validation or numeric validation based on key
    private void setupEditText(String key) {
        EditTextPreference editPref = findPreference(key);
        if (editPref != null) {
            editPref.setOnPreferenceChangeListener((preference, newValue) -> {
                String value = (String) newValue;

                // Validation for phone numbers
                if (key.equals("alert_phone_number")) {
                    if (value.isEmpty()) {
                        showToast("Phone number cannot be empty");
                        return false; // Reject empty values
                    }
                    if (!value.matches(PHONE_NUMBER_PATTERN)) {
                        showToast("Enter a valid phone number (10-15 digits)");
                        return false; // Reject invalid format
                    }
                    return true; // Accept valid phone number
                }

                // Validation for MPG numeric values
                try {
                    if (!value.isEmpty()) Double.parseDouble(value); // Validate it's a number
                    return true; // Accept valid number or empty string
                } catch (NumberFormatException e) {
                    showToast("Invalid number");
                    return false; // Reject invalid numbers
                }
            });
        }
    }

    /** Checks permissions and sends test SMS when enabled
     * @param switchKey key of the switch preference
     * @param valueKey key of the associated value preference (e.g., MPG threshold)
     * @param smsMessagePrefix prefix for the SMS message
     */
    private void setupSwitch(String switchKey, String valueKey, String smsMessagePrefix) {
        SwitchPreferenceCompat switchPref = findPreference(switchKey);
        EditTextPreference editPref = findPreference(valueKey);

        if (switchPref != null) {
            switchPref.setOnPreferenceChangeListener((preference, newValue) -> {
                boolean enabled = (Boolean) newValue;

                // Only validate when user tries to enable the switch
                if (enabled) {
                    // Check if SMS permission is granted
                    if (!hasSmsPermission()) {
                        // Request permission
                        smsPermissionLauncher.launch(Manifest.permission.SEND_SMS);
                        // Keep switch disabled until permission is granted
                        return false;
                    }

                    // Check if phone number is configured
                    String phoneNumber = getStringPref(requireContext(), "alert_phone_number", "");
                    if (phoneNumber.isEmpty()) {
                        showToast("Please set a phone number in settings first");
                        return false; // Prevent enabling without phone number
                    }

                    // Send test SMS if threshold value exists
                    if (editPref != null) {
                        String editTextValue = editPref.getText();
                        if (editTextValue != null && !editTextValue.isEmpty()) {
                            String message = smsMessagePrefix + editTextValue;
                            sendSms(phoneNumber, message);
                        }
                    }
                }

                return true; // Allow the preference change
            });
        }
    }

    // Send an SMS message to the specified phone number
    private void sendSms(String phoneNumber, String message) {
        // Double-check permission (defensive programming)
        if (!hasSmsPermission()) {
            showToast("SMS permission not granted");
            return;
        }

        try {
            // Get default SMS manager and send message
            SmsManager smsManager = SmsManager.getDefault();
            // sendTextMessage is already async - returns immediately without blocking UI
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            showToast("SMS sent successfully");
        } catch (Exception e) {
            Log.e(TAG, "Failed to send SMS", e);
            showToast("Failed to send SMS: " + e.getMessage());
        }
    }

    // Helper method to check if SMS permission is granted
    @SuppressWarnings("BooleanMethodIsAlwaysInverted")
    private boolean hasSmsPermission() {
        return ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.SEND_SMS)
                == android.content.pm.PackageManager.PERMISSION_GRANTED;
    }

    // Safe toast display with null checking
    private void showToast(String message) {
        Context context = getContext();
        if (context != null) {
            Toast.makeText(context, message, Toast.LENGTH_SHORT).show();
        }
    }

    // Check current MPG against alert thresholds and send SMS if needed
    public static void checkMPGAlerts(Context context) {
        // Get current 4-week average MPG
        float currentMPG = MainActivity.getLast4WeeksMPG(context);

        // No MPG data available
        if (currentMPG <= 0) {
            return;
        }

        // Get phone number
        String phoneNumber = getStringPref(context, "alert_phone_number", "");
        if (phoneNumber.isEmpty()) {
            return;
        }

        // Retrieve boolean preference with key "alert_mpg_low" from SharedPreferences
        if (getBooleanPref(context, "alert_mpg_low", false)) {
            // Retrieve the user-specified low MPG threshold value
            String lowThresholdStr = getStringPref(context, "mpg_low_value", "");
            // Ensure the threshold value is not empty before parsing
            if (!lowThresholdStr.isEmpty()) {
                try { // Convert string threshold to float for numerical comparison
                    float lowThreshold = Float.parseFloat(lowThresholdStr);
                    // Check if current MPG is below the user's threshold
                    if (currentMPG < lowThreshold) {
                        // Format the alert message with current MPG and threshold
                        String message = String.format(Locale.US,
                                "Warning: Your MPG (%.1f) is below the low threshold (%.1f)",
                                currentMPG, lowThreshold
                        ); // Send SMS alert to the configured phone number
                        sendAlertSms(phoneNumber, message);
                    }
                } catch (NumberFormatException e) { // Handle invalid input
                    Log.e(TAG, "Invalid low MPG threshold", e);
                }
            }
        }

        // Check high MPG alert (same logic as the low one)
        if (getBooleanPref(context, "alert_mpg_high", false)) {
            String highThresholdStr = getStringPref(context, "mpg_high_value", "");
            if (!highThresholdStr.isEmpty()) {
                try {
                    float highThreshold = Float.parseFloat(highThresholdStr);
                    if (currentMPG > highThreshold) {
                        String message = String.format(Locale.US,
                                "Great news! Your MPG (%.1f) is above the high threshold (%.1f)",
                                currentMPG, highThreshold
                        );
                        sendAlertSms(phoneNumber, message);
                    }
                } catch (NumberFormatException e) {
                    Log.e(TAG, "Invalid high MPG threshold", e);
                }
            }
        }
    }

    // Send alert SMS (static method for use from other classes)
    private static void sendAlertSms(String phoneNumber, String message) {
        try { // Get the default SMS manager instance
            SmsManager smsManager = SmsManager.getDefault();
            // - phoneNumber: Destination phone number (String)
            // - null: Service center address (null for default)
            // - message: Text content of the SMS
            // - null: PendingIntent for sent confirmation (null = no notification)
            // - null: PendingIntent for delivery confirmation (null = no notification)
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Log.d(TAG, "Alert SMS sent: " + message); // Log success for debugging
        } catch (Exception e) { // Catch all exceptions
            Log.e(TAG, "Failed to send alert SMS", e); // Log failure
        }
    }

    // ========== Static Helper Methods ==========

    /** Utility method to read string preference from anywhere in the app
     * @param context Application context
     * @param key Preference key
     * @param defaultValue Default value if preference doesn't exist
     * @return The preference value or default
     */
    public static String getStringPref(Context context, String key, String defaultValue) {
        return androidx.preference.PreferenceManager.getDefaultSharedPreferences(context)
                .getString(key, defaultValue);
    }

    // Utility method to read boolean preference from anywhere in the app
    public static boolean getBooleanPref(Context context, String key, boolean defaultValue) {
        return androidx.preference.PreferenceManager.getDefaultSharedPreferences(context)
                .getBoolean(key, defaultValue);
    }
}