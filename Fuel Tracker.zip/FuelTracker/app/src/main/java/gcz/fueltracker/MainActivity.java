package gcz.fueltracker;

import android.annotation.SuppressLint;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.PopupMenu;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.preference.PreferenceManager;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import gcz.fueltracker.database.AppDatabase;
import gcz.fueltracker.database.DatabaseClient;
import gcz.fueltracker.database.FuelRefill;
import gcz.fueltracker.database.FuelRefillDao;
import gcz.fueltracker.database.User;
import gcz.fueltracker.database.UserDao;

@SuppressWarnings("ExtractMethodRecommender")
public class MainActivity extends AppCompatActivity { // Main entry point activity

    private static final String PREF_LAST_4_WEEKS_MPG = "last_4_weeks_mpg";
    private Button buttonHomeLogin; // Login button on home screen
    private View appName;           // App title/logo view on home screen
    private User currentUser;       // Currently logged-in user
    private SessionManager sessionManager; // Handles persistent login state

    // Lifecycle method called when activity is first created
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState); // Call parent implementation

        // Initialize SessionManager to handle persistent login sessions
        sessionManager = new SessionManager(this);

        // Check if user is already logged in from previous session
        String savedUsername = sessionManager.getLoggedInUsername();
        if (savedUsername != null && !savedUsername.isEmpty()) {
            // User session exists - load user data and redirect to main app
            new Thread(() -> { // Database operations on background thread
                AppDatabase db = DatabaseClient.getInstance(this); // Get database instance
                UserDao userDao = db.userDao(); // Get User Data Access Object
                User user = userDao.getUserByUsername(savedUsername); // Query user from DB

                if (user != null) { // Valid user found in database
                    currentUser = user; // Store user in memory

                    // Calculate and save MPG for last 4 weeks
                    calculateAndSaveLast4WeeksMPG(db, savedUsername);

                    runOnUiThread(() -> { // Switch back to UI thread for updates
                        // Welcome back message
                        Toast.makeText(this, "Welcome back, " + user.getUsername() + "!", Toast.LENGTH_SHORT).show();
                        // Load layout before opening fragment (ensures views exist)
                        setContentView(R.layout.activity_main);
                        initializeViews(); // Set up UI elements
                        openFragment(new FuelRefillFragment(currentUser));
                    });
                } else {
                    // No user found, show home screen (will prompt for login)
                    setContentView(R.layout.activity_main);
                    initializeViews();
                }
            }).start(); // Execute the background thread
        } else {
            // No saved session exists - show home screen with login button
            setContentView(R.layout.activity_main); // Inflate layout XML
            initializeViews(); // Set up UI components
        }
    }

    // Initialize views and menu
    private void initializeViews() {
        // Find views by their resource IDs from the inflated layout
        buttonHomeLogin = findViewById(R.id.buttonHomeLogin);
        appName = findViewById(R.id.appName);
        ImageButton menuButton = findViewById(R.id.menuButton);

        // Set click listener for login button (opens login screen)
        buttonHomeLogin.setOnClickListener(v -> openLoginFragment());

        // Listen for fragment back stack changes to show/hide home screen elements
        getSupportFragmentManager().addOnBackStackChangedListener(() -> {
            // When back stack is empty (returned to home screen)
            if (getSupportFragmentManager().getBackStackEntryCount() == 0) {
                buttonHomeLogin.setVisibility(View.VISIBLE); // Show login button
                appName.setVisibility(View.VISIBLE);         // Show app name
            }
        });

        // Configure menu button click handler
        menuButton.setOnClickListener(view -> {
            // Create popup menu anchored to the menu button
            PopupMenu popup = new PopupMenu(MainActivity.this, view);
            // Inflate menu from XML resource
            popup.getMenuInflater().inflate(R.menu.appbar_menu, popup.getMenu());

            // Update menu item text based on login state
            if (currentUser != null) {
                // User is logged in - change "Login" to "Logout"
                popup.getMenu().findItem(R.id.action_login).setTitle("Logout");
            }

            // Handle menu item selections
            popup.setOnMenuItemClickListener(item -> {
                int id = item.getItemId(); // Get ID of clicked menu item

                if (id == R.id.action_fuel) { // Fuel Refill page
                    if (currentUser != null) {
                        openFragment(new FuelRefillFragment(currentUser));
                    } else {
                        Toast.makeText(this, "Please login first", Toast.LENGTH_SHORT).show();
                        openLoginFragment();
                    }
                } else if (id == R.id.action_database) { // Database page
                    if (currentUser != null) {
                        openFragment(new DatabaseFragment(currentUser));
                    } else {
                        Toast.makeText(this, "Please login first", Toast.LENGTH_SHORT).show();
                        openLoginFragment();
                    }
                } else if (id == R.id.action_stats) { // Statistics page
                    openFragment(StatisticsFragment.newInstance(currentUser));
                } else if (id == R.id.action_settings) { // Settings page
                    openFragment(new SettingsFragment());
                } else if (id == R.id.action_login) { // Login/Logout
                    if (currentUser != null) {
                        logoutUser();
                    } else {
                        openLoginFragment();
                    }
                } else if (id == R.id.action_about) { // About page
                    openFragment(new AboutFragment());
                }

                return true; // Consume the click event
            });

            popup.show(); // Display the popup menu
        });
    }

    // Public method to open fragments
    public void openFragment(Fragment fragment) {
        // Safety check: ensure UI is initialized before fragment transaction
        if (buttonHomeLogin == null || appName == null) {
            setContentView(R.layout.activity_main);
            initializeViews();
        }

        // Hide home screen elements when showing a fragment
        buttonHomeLogin.setVisibility(View.GONE);
        appName.setVisibility(View.GONE);

        // Perform fragment transaction
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.fullPageContainer, fragment) // Replace container contents
                .addToBackStack(null) // Allow back navigation
                .commit(); // Execute the transaction
    }

    // Open LoginFragment with callback for login results
    @SuppressLint("SetTextI18n")
    private void openLoginFragment() {
        LoginFragment fragment = new LoginFragment();
        // Set callback to handle login success/failure
        fragment.setLoginCallback(user -> {
            if (user != null) { // Login successful
                currentUser = user; // Store user in memory
                sessionManager.saveLogin(user.getUsername()); // Save session persistently
                buttonHomeLogin.setText("@string/logout"); // Change Login/Logout button

                // Calculate and save MPG when user logs in
                new Thread(() -> {
                    AppDatabase db = DatabaseClient.getInstance(this);
                    calculateAndSaveLast4WeeksMPG(db, user.getUsername());
                }).start();

                openFragment(new FuelRefillFragment(currentUser)); // Go to Fuel Refill page
            } else {
                logoutUser(); // Login failed or logout requested (user = null)
            }
        });
        openFragment(fragment); // Display login fragment
    }

    // Logout user and clear session
    @SuppressLint("SetTextI18n")
    private void logoutUser() {
        currentUser = null; // Clear in-memory user
        sessionManager.logout(); // Clear persistent session
        buttonHomeLogin.setText("@string/login"); // Change Login/Logout button
        Toast.makeText(this, "Logged out successfully", Toast.LENGTH_SHORT).show();

        // Always open Login Fragment after logout
        LoginFragment loginFragment = new LoginFragment();
        loginFragment.setLoginCallback(user -> {
            if (user != null) { // User logged in again after logout
                currentUser = user;
                sessionManager.saveLogin(user.getUsername());
                buttonHomeLogin.setText("@string/logout");

                // Calculate and save MPG when user logs in
                new Thread(() -> {
                    AppDatabase db = DatabaseClient.getInstance(this);
                    calculateAndSaveLast4WeeksMPG(db, user.getUsername());
                }).start();

                openFragment(new FuelRefillFragment(currentUser));
            }
        });

        // Replace current fragment with login (without adding to back stack)
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.fullPageContainer, loginFragment)
                .commit();
    }

    // Calculate average MPG for the last 4 weeks and save to SharedPreferences.
      private void calculateAndSaveLast4WeeksMPG(AppDatabase db, String username) {
        FuelRefillDao dao = db.fuelRefillDao();
        List<FuelRefill> records = dao.getRefillsForUser(username);

        if (records == null || records.size() < 2) {
            // Not enough data to calculate MPG
            saveMPGToPreferences(0f);
            return;
        }

        // Sort records by timestamp (oldest to newest)
        records.sort((r1, r2) -> {
            Date d1 = parseFlexibleDate(r1.getTimestamp());
            Date d2 = parseFlexibleDate(r2.getTimestamp());
            if (d1 == null || d2 == null) return 0;
            return d1.compareTo(d2);
        });

        // Calculate date 4 weeks ago
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.WEEK_OF_YEAR, -4);
        Date fourWeeksAgo = calendar.getTime();

        // Calculate MPG for last 4 weeks
        float totalMPG = 0f;
        int mpgCount = 0;

        // Iterate through consecutive refill pairs
        for (int i = 1; i < records.size(); i++) {
            FuelRefill previousRefill = records.get(i - 1);
            FuelRefill currentRefill = records.get(i);

            // Check if current refill is within last 4 weeks
            Date refillDate = parseFlexibleDate(currentRefill.getTimestamp());
            if (refillDate == null || refillDate.before(fourWeeksAgo)) {
                continue; // Skip refills older than 4 weeks
            }

            // Calculate gallons purchased at current refill
            float gallons = currentRefill.getTotalCost() / currentRefill.getCostPerGallon();

            // Calculate miles driven since previous refill
            int milesDriven = currentRefill.getMileage() - previousRefill.getMileage();

            // Skip invalid data (negative or zero miles/gallons)
            if (milesDriven <= 0 || gallons <= 0) {
                continue;
            }

            // Calculate MPG for this interval
            float mpg = milesDriven / gallons;
            totalMPG += mpg;
            mpgCount++;
        }

        // Calculate and save average MPG
        float averageMPG = mpgCount > 0 ? totalMPG / mpgCount : 0f;
        saveMPGToPreferences(averageMPG);
    }

    // Save calculated MPG to SharedPreferences.
    private void saveMPGToPreferences(float mpg) {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
        prefs.edit().putFloat(PREF_LAST_4_WEEKS_MPG, mpg).apply();
    }

    // Parse date string with multiple formats.
    private Date parseFlexibleDate(String input) {
        if (input == null || input.trim().isEmpty()) {
            return null;
        }

        // List of supported date formats, tried in order
        String[] patterns = {
                "yyyy-MM-dd",
                "yyyy-MM-dd HH:mm",
                "yyyy-MM-dd H:mm",
                "yyyy-MM-dd HH:mm:ss",
                "M/d/yyyy HH:mm:ss a",
                "M/d/yyyy h:mm:ss a"
        };

        // Try each pattern until one succeeds
        for (String pattern : patterns) {
            try {
                return new SimpleDateFormat(pattern, Locale.US).parse(input);
            } catch (Exception ignored) {
                // Continue to next pattern
            }
        }

        return null;
    }

    // Getter method for current user (used by fragments)
    public User getCurrentUser() {
        return currentUser;
    }

    // Public method to recalculate MPG after adding a new refill
    public void updateMPGCalculation() {
        if (currentUser != null) {
            new Thread(() -> {
                AppDatabase db = DatabaseClient.getInstance(this);
                calculateAndSaveLast4WeeksMPG(db, currentUser.getUsername());
            }).start();
        }
    }

    // Static method to get the last 4 weeks MPG from SharedPreferences
    public static float getLast4WeeksMPG(android.content.Context context) {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context);
        return prefs.getFloat(PREF_LAST_4_WEEKS_MPG, 0f);
    }
}