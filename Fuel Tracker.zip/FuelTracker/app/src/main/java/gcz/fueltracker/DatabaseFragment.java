package gcz.fueltracker;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputFilter;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import gcz.fueltracker.database.AppDatabase;
import gcz.fueltracker.database.DatabaseClient;
import gcz.fueltracker.database.FuelRefill;
import gcz.fueltracker.database.FuelRefillDao;
import gcz.fueltracker.database.User;

// Main fragment class for displaying and managing fuel refill records
public class DatabaseFragment extends Fragment {

    @SuppressWarnings("FieldCanBeLocal")
    private RecyclerView recyclerView; // Display the list of records
    private FuelRefillAdapter adapter; // Adapter for the RecyclerView
    private final List<FuelRefill> records = new ArrayList<>(); // Data source for adapter
    private final User currentUser; // Currently logged-in user object
    private ActivityResultLauncher<String[]> csvPickerLauncher; // Launcher for CSV file picker
    private static final String TAG = "DatabaseFragment";  // Logging tag

    public DatabaseFragment(User user) { // Store the passed user for database operations
        this.currentUser = user;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Initialize CSV picker launcher
        csvPickerLauncher = registerForActivityResult(
                new ActivityResultContracts.OpenDocument(),
                uri -> {
                    if (uri != null) {
                        importCsvFile(uri); // Import the selected CSV file
                    }
                }
        );

        loadRecordsFromDb(); // Load existing records from database when fragment is created
    }

    // Load records from database for current user in background thread
    @SuppressLint("NotifyDataSetChanged")
    private void loadRecordsFromDb() {
        // Get database instance using singleton pattern
        AppDatabase db = DatabaseClient.getInstance(requireContext());
        // Get DAO for fuel refill operations
        FuelRefillDao dao = db.fuelRefillDao();
        // Create new thread for database operations
        new Thread(() -> {
            // Query database for all refills for current user
            List<FuelRefill> list = dao.getRefillsForUser(currentUser.getUsername());
            if (list != null) {
                records.clear();      // Clear existing records list
                records.addAll(list); // Add all retrieved records to local list
                // Switch to UI thread to update RecyclerView
                requireActivity().runOnUiThread(() -> {
                    // Notify adapter that data changed (refresh display)
                    if (adapter != null) adapter.notifyDataSetChanged();
                });
            }
        }).start(); // Start the background thread
    }

    // Creates and returns the fragment's UI
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        // Inflate the layout from XML
        View view = inflater.inflate(R.layout.fragment_database, container, false);

        // Initialize UI components from the layout
        recyclerView = view.findViewById(R.id.recyclerFuelEntries);
        Button buttonAdd = view.findViewById(R.id.buttonAddEntry);
        Button buttonImportCsv = view.findViewById(R.id.buttonImportCsv);

        // Create adapter with click listeners for edit/delete actions
        adapter = new FuelRefillAdapter(records, new FuelRefillAdapter.OnRecordActionListener() {
            @Override
            public void onEdit(FuelRefill refill) {
                showEditDialog(refill);
            }

            @Override
            public void onDelete(FuelRefill refill) {
                // Show confirmation dialog before deleting
                new AlertDialog.Builder(getContext())
                        .setTitle("Delete Confirmation")
                        .setMessage("Are you sure you want to delete this record?")
                        .setPositiveButton("Yes", (dialog, which) -> deleteRecord(refill))
                        .setNegativeButton("No", null) // Do nothing
                        .show();
            }
        });

        // Set up RecyclerView with linear layout (vertical list)
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.setAdapter(adapter); // Connect adapter to RecyclerView

        // Set click listener for add button
        buttonAdd.setOnClickListener(v -> showAddDialog());

        // Set click listener for import CSV button
        buttonImportCsv.setOnClickListener(v -> {
            // Launch file picker to select CSV file
            csvPickerLauncher.launch(new String[]{"text/csv", "text/comma-separated-values", "text/*"});
        });

        return view; // Return the created view
    }

    // Imports fuel records from a CSV file
    @SuppressLint("NotifyDataSetChanged")
    private void importCsvFile(Uri uri) {
        AppDatabase db = DatabaseClient.getInstance(requireContext());
        FuelRefillDao dao = db.fuelRefillDao();

        new Thread(() -> {
            int successCount = 0; // Track successfully imported records
            int errorCount = 0;   // Track records with errors
            List<FuelRefill> importedRecords = new ArrayList<>(); // Temporarily store imported records
            List<String> errorMessages = new ArrayList<>(); // Track specific errors

            try {
                // Open input stream from the selected file URI
                BufferedReader reader = new BufferedReader(
                        new InputStreamReader(requireContext().getContentResolver().openInputStream(uri))
                );

                String line;
                boolean isFirstLine = true; // Flag to skip header row
                int lineNumber = 0; // Track line number for error reporting

                // Read file line by line
                while ((line = reader.readLine()) != null) {
                    lineNumber++;

                    // Skip empty lines
                    if (line.trim().isEmpty()) {
                        continue;
                    }

                    // Skip header row (first line)
                    if (isFirstLine) {
                        isFirstLine = false;
                        Log.d(TAG, "Skipping header: " + line);
                        continue;
                    }

                    // Parse CSV line by splitting on commas
                    String[] values = line.split(",");

                    Log.d(TAG, "Line " + lineNumber + ": Found " + values.length + " columns");

                    // Expected format: timestamp, station, mileage, costPerGallon, totalCost
                    if (values.length >= 5) {
                        try {
                            // Extract and trim each field
                            String timestamp = values[0].trim();
                            String station = values[1].trim();
                            String mileageStr = values[2].trim();
                            String costPerGallonStr = values[3].trim().replace("$", ""); // Remove $ sign
                            String totalCostStr = values[4].trim().replace("$", ""); // Remove $ sign

                            Log.d(TAG, "Parsing - Time: '" + timestamp + "', Station: '" + station +
                                    "', Mileage: '" + mileageStr + "', CPG: '" + costPerGallonStr +
                                    "', Total: '" + totalCostStr + "'");

                            int mileage = Integer.parseInt(mileageStr);
                            float costPerGallon = Float.parseFloat(costPerGallonStr);
                            float totalCost = Float.parseFloat(totalCostStr);

                            // Create new FuelRefill object
                            FuelRefill refill = new FuelRefill(
                                    currentUser.getId(),
                                    currentUser.getUsername(),
                                    timestamp,
                                    station,
                                    mileage,
                                    costPerGallon,
                                    totalCost
                            );

                            dao.insertRefill(refill); // Insert into database
                            importedRecords.add(refill);
                            successCount++;
                            Log.d(TAG, "✅ Successfully imported line " + lineNumber);

                        } catch (NumberFormatException e) {
                            // Handle parsing errors for numeric fields
                            errorCount++;
                            String error = "Line " + lineNumber + ": " + e.getMessage();
                            errorMessages.add(error);
                            Log.e(TAG, "❌ Error parsing line " + lineNumber + ": " + line, e);
                        }
                    } else {
                        // Handle lines with insufficient columns
                        errorCount++;
                        String error = "Line " + lineNumber + ": Expected 5 columns, found " + values.length;
                        errorMessages.add(error);
                        Log.e(TAG, "❌ Invalid line format at line " + lineNumber + ": " + line);
                    }
                }
                reader.close();

                // Update UI on main thread
                int finalSuccessCount = successCount;
                int finalErrorCount = errorCount;

                requireActivity().runOnUiThread(() -> {
                    // Add all imported records to the main list
                    records.addAll(importedRecords);
                    adapter.notifyDataSetChanged(); // Refresh RecyclerView

                    // Show import summary message
                    String message = finalSuccessCount + " records imported successfully";
                    if (finalErrorCount > 0) {
                        message += ", " + finalErrorCount + " errors";

                        // Show detailed error dialog
                        StringBuilder errorDetail = new StringBuilder();
                        errorDetail.append("Errors found:\n\n");
                        for (String error : errorMessages) {
                            errorDetail.append("• ").append(error).append("\n");
                        }

                        new AlertDialog.Builder(getContext())
                                .setTitle("Import Errors")
                                .setMessage(errorDetail.toString())
                                .setPositiveButton("OK", null)
                                .show();
                    }
                    Toast.makeText(getContext(), message, Toast.LENGTH_LONG).show();

                    // Log summary
                    Log.d(TAG, "========== IMPORT SUMMARY ==========");
                    Log.d(TAG, "Success: " + finalSuccessCount);
                    Log.d(TAG, "Errors: " + finalErrorCount);
                    Log.d(TAG, "===================================");
                });

            } catch (Exception e) {
                // Handle file reading errors
                Log.e(TAG, "Error importing CSV", e);
                requireActivity().runOnUiThread(() ->
                        Toast.makeText(getContext(), "Error importing CSV: " + e.getMessage(),
                                Toast.LENGTH_LONG).show()
                );
            }
        }).start(); // Run import operation on background thread
    }

    @SuppressWarnings("unused")
    public int getLastMileage() {
        if (!records.isEmpty()) {
            // Return last record's mileage
            return records.get(records.size() - 1).getMileage();
        }
        return 0; // Default if no records exist
    }

    // Delete record from database and UI
    @SuppressLint("NotifyDataSetChanged")
    private void deleteRecord(FuelRefill refill) {
        AppDatabase db = DatabaseClient.getInstance(requireContext());
        FuelRefillDao dao = db.fuelRefillDao();
        new Thread(() -> {
            dao.deleteRefill(refill);
            records.remove(refill);
            requireActivity().runOnUiThread(() -> adapter.notifyDataSetChanged());
        }).start();
    }

    // Shows dialog for adding new fuel records
    @SuppressWarnings("unused")
    private void showAddDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        builder.setTitle("Add Fuel Record");

        // Inflate the dialog layout
        View dialogView = LayoutInflater.from(getContext()).inflate(R.layout.dialog_add_record, null);
        builder.setView(dialogView);

        // Get references to input fields
        EditText inputDate = dialogView.findViewById(R.id.editDate);
        EditText inputStation = dialogView.findViewById(R.id.editBrand);
        EditText inputMileage = dialogView.findViewById(R.id.editMileage);
        EditText inputCost = dialogView.findViewById(R.id.editCost);
        EditText inputTotal = dialogView.findViewById(R.id.editTotal);
        Spinner spinnerStation = dialogView.findViewById(R.id.spinnerBrand);

        // Set current timestamp
        String now = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(new Date());
        inputDate.setText(now);

        // Input validation for station field
        inputStation.setFilters(new InputFilter[]{
                (source, start, end, dest, dstart, dend) -> {
                    if (source.toString().matches("[a-zA-Z0-9-']*")) return null; // Allow if valid
                    Toast.makeText(getContext(), "Station cannot contain special characters", Toast.LENGTH_SHORT).show();
                    return ""; // Reject invalid input
                }
        });

        // Input validation for mileage field
        inputMileage.setFilters(new InputFilter[]{
                (source, start, end, dest, dstart, dend) -> {
                    String result = dest.toString().substring(0, dstart) + source + dest.toString().substring(dend);
                    if (result.matches("\\d*")) return null; // Allow if all digits
                    Toast.makeText(getContext(), "Mileage can only contain numbers", Toast.LENGTH_SHORT).show();
                    return ""; // Reject invalid input
                }
        });

        // Spinner for station selection
        spinnerStation.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                // Auto-fill station field when spinner item is selected
                inputStation.setText(parent.getItemAtPosition(position).toString());
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) { }
        });

        // Set up dialog buttons
        builder.setPositiveButton("Add", (dialog, which) -> {
            // Validate inputs and add record if valid
            FuelRefill refill = validateAndCreateFuelRefill(dialogView);
            if (refill != null) {
                checkMileageAndInsert(refill); // Check mileage before inserting
            }
        });

        builder.setNegativeButton("Cancel", null); // Close dialog on cancel
        builder.show(); // Display the dialog
    }

    // Validates user inputs and creates FuelRefill object if valid
    private FuelRefill validateAndCreateFuelRefill(View dialogView) {
        // Get references to all input fields
        EditText inputDate = dialogView.findViewById(R.id.editDate);
        EditText inputStation = dialogView.findViewById(R.id.editBrand);
        EditText inputMileage = dialogView.findViewById(R.id.editMileage);
        EditText inputCost = dialogView.findViewById(R.id.editCost);
        EditText inputTotal = dialogView.findViewById(R.id.editTotal);

        // Extract and trim text from inputs
        String date = inputDate.getText().toString().trim();
        String station = inputStation.getText().toString().trim();
        String mileageStr = inputMileage.getText().toString().trim();
        String costStr = inputCost.getText().toString().trim();
        String totalStr = inputTotal.getText().toString().trim();

        // Check for empty fields
        if (date.isEmpty() || station.isEmpty() || mileageStr.isEmpty() ||
                costStr.isEmpty() || totalStr.isEmpty()) {
            Toast.makeText(getContext(), "All fields are required.", Toast.LENGTH_SHORT).show();
            return null; // Validation failed
        }

        try { // Parse numeric values
            int mileage = Integer.parseInt(mileageStr);
            float cost = Float.parseFloat(costStr);
            float total = Float.parseFloat(totalStr);

            // Check for negative numbers
            if (mileage < 0 || cost < 0 || total < 0) {
                Toast.makeText(getContext(), "Numbers cannot be negative.", Toast.LENGTH_SHORT).show();
                return null; // Validation failed
            }

            // FuelRefill constructor: int userId, String username, String timestamp, String station, int mileage, float costPerGallon, float totalCost
            return new FuelRefill(currentUser.getId(), currentUser.getUsername(),
                    date, station, mileage, cost, total);

        } catch (NumberFormatException e) {
            Toast.makeText(getContext(), "Invalid number format.", Toast.LENGTH_SHORT).show();
            return null; // Validation failed
        }
    }

    // Validates mileage progression logic
    private void checkMileageAndInsert(FuelRefill newRefill) {
        if (!records.isEmpty()) {
            int lastMileage = records.get(records.size() - 1).getMileage();

            // Check if new mileage is less than last recorded mileage
            if (newRefill.getMileage() < lastMileage) {
                new AlertDialog.Builder(getContext())
                        .setTitle("Mileage Warning")
                        .setMessage("The mileage you entered (" + newRefill.getMileage() +
                                ") is smaller than the last record (" + lastMileage + ").\n\n" +
                                "Are you sure?\nLowering mileage is against the law! \uD83D\uDE01")
                        // Insert anyway if user confirms
                        .setPositiveButton("Yes", (d, w) -> insertRecord(newRefill))
                        // Cancel if user says no
                        .setNegativeButton("No", null)
                        .show();
                return; // Wait for user decision
                // Check if new mileage equals last recorded mileage
            } else if (newRefill.getMileage() == lastMileage) {
                new AlertDialog.Builder(getContext())
                        .setTitle("Mileage Warning")
                        .setMessage("The mileage you entered (" + newRefill.getMileage() +
                                ") is equal to the last record (" + lastMileage + ").\n\n" +
                                "Are you sure?")
                        .setPositiveButton("Yes", (d, w) -> insertRecord(newRefill))
                        .setNegativeButton("No", null)
                        .show();
                return; // Wait for user decision
            }
        }

        // If no issues or user confirmed, insert the record
        insertRecord(newRefill);
    }

    // Adds a new record to the database and updates UI
    private void insertRecord(FuelRefill refill) {
        AppDatabase db = DatabaseClient.getInstance(requireContext());
        FuelRefillDao dao = db.fuelRefillDao();
        new Thread(() -> { // Run in background thread
            dao.insertRefill(refill); // Insert into database
            records.add(refill);// Add to local list
            // Notify adapter of new item
            requireActivity().runOnUiThread(() -> adapter.notifyItemInserted(records.size() - 1)); // Notify adapter of new item
        }).start();
    }

    // Shows dialog for editing existing records
    private void showEditDialog(FuelRefill refill) {
        // Similar to add dialog but pre-populates with existing data
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        builder.setTitle("Edit Fuel Record");

        View dialogView = LayoutInflater.from(getContext()).inflate(R.layout.dialog_add_record, null);
        builder.setView(dialogView);

        // Pre-populate fields with existing record data
        EditText inputDate = dialogView.findViewById(R.id.editDate);
        EditText inputStation = dialogView.findViewById(R.id.editBrand);
        EditText inputMileage = dialogView.findViewById(R.id.editMileage);
        EditText inputCost = dialogView.findViewById(R.id.editCost);
        EditText inputTotal = dialogView.findViewById(R.id.editTotal);
        Spinner spinnerStation = dialogView.findViewById(R.id.spinnerBrand);

        inputDate.setText(refill.getTimestamp());
        inputStation.setText(refill.getStation());
        inputMileage.setText(String.valueOf(refill.getMileage()));
        inputCost.setText(String.valueOf(refill.getCostPerGallon()));
        inputTotal.setText(String.valueOf(refill.getTotalCost()));

        // Input validation for station field
        inputStation.setFilters(new InputFilter[]{
                (source, start, end, dest, dstart, dend) -> {
                    if (source.toString().matches("[a-zA-Z0-9]*")) return null; // Allow if valid
                    Toast.makeText(getContext(), "Station can only contain letters and numbers", Toast.LENGTH_SHORT).show();
                    return ""; // Reject invalid input
                }
        });

        // Input validation for mileage field
        inputMileage.setFilters(new InputFilter[]{
                (source, start, end, dest, dstart, dend) -> {
                    String result = dest.toString().substring(0, dstart) + source + dest.toString().substring(dend);
                    if (result.matches("\\d*")) return null; // Allow if all digits
                    Toast.makeText(getContext(), "Mileage can only contain numbers", Toast.LENGTH_SHORT).show();
                    return ""; // Reject invalid input
                }
        });

        // Select matching station in spinner
        for (int i = 0; i < spinnerStation.getCount(); i++) {
            if (spinnerStation.getItemAtPosition(i).toString().equals(refill.getStation())) {
                spinnerStation.setSelection(i);
                break;
            }
        }

        // Same spinner listener as add dialog
        spinnerStation.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                // Auto-fill station field when spinner item is selected
                inputStation.setText(parent.getItemAtPosition(pos).toString());
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) { }
        });

        builder.setPositiveButton("Save", (dialog, which) -> {
            // Validate inputs and update record if valid
            FuelRefill updated = validateAndCreateFuelRefill(dialogView);
            if (updated == null) return; // Validation failed

            // Update database
            AppDatabase db = DatabaseClient.getInstance(requireContext());
            FuelRefillDao dao = db.fuelRefillDao();
            new Thread(() -> {
                dao.deleteRefill(refill);  // simple approach: delete old
                dao.insertRefill(updated);  // insert updated
                int index = records.indexOf(refill);
                records.set(index, updated);
                requireActivity().runOnUiThread(() -> adapter.notifyItemChanged(index)); // Notify adapter that data changed
            }).start();
        });

        builder.setNegativeButton("Cancel", null); // Close dialog on cancel
        builder.show(); // Display the dialog
    }
}