package gcz.fueltracker.database;

import androidx.room.Entity;
import androidx.room.PrimaryKey;
import androidx.room.ColumnInfo;

@Entity(tableName = "fuel_refill") // mark this class as a Room database table
public class FuelRefill {

    @PrimaryKey(autoGenerate = true) // generate automatically unique ID values
    private int id;                  // auto-incremented by Room

    @ColumnInfo(name = "user_id")    // set column name to "user_id"
    private int userId;              // foreign key reference

    @ColumnInfo(name = "username")   // set column name to "username"
    private String username;

    @ColumnInfo(name = "timestamp")  // set column name to "timestamp"
    private String timestamp;

    @ColumnInfo(name = "station")    // set column name to "station"
    private String station;

    @ColumnInfo(name = "mileage")    // set column name to "mileage"
    private int mileage;

    @ColumnInfo(name = "cost_per_gallon") // set column name to "cost_per_gallon"
    private float costPerGallon;

    @ColumnInfo(name = "total_cost") // set column name to "total_cost"
    private float totalCost;

    public FuelRefill(int userId, String username, String timestamp, String station,
                      int mileage, float costPerGallon, float totalCost) {
        // constructor - Room will use this to create entity instances
        this.userId = userId;
        this.username = username;
        this.timestamp = timestamp;
        this.station = station;
        this.mileage = mileage;
        this.costPerGallon = costPerGallon;
        this.totalCost = totalCost;
    }

    // Getters and setters - primary key getter/setter
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    // User ID getter/setter
    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }

    // Username getter/setter
    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    // Timestamp getter/setter
    public String getTimestamp() { return timestamp; }
    public void setTimestamp(String timestamp) { this.timestamp = timestamp; }

    // Station getter/setter
    public String getStation() { return station; }
    public void setStation(String station) { this.station = station; }

    // Mileage getter/setter
    public int getMileage() { return mileage; }
    public void setMileage(int mileage) { this.mileage = mileage; }

    // Cost per gallon getter/setter
    public float getCostPerGallon() { return costPerGallon; }
    public void setCostPerGallon(float costPerGallon) { this.costPerGallon = costPerGallon; }

    // Total cost getter/setter
    public float getTotalCost() { return totalCost; }
    public void setTotalCost(float totalCost) { this.totalCost = totalCost; }
}