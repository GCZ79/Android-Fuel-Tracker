package gcz.fueltracker;

import java.io.Serializable;

// Record class representing a fuel purchase record with Serializable capability
public class Record implements Serializable {
    // Private instance variables storing record data
    private String date;  // Date of fuel purchase (format likely: "YYYY-MM-DD HH:mm")
    private String brand; // Gas station brand/name (e.g., "Shell", "Chevron")
    private int mileage;  // Vehicle odometer reading at time of refill
    private double cost;  // Cost per gallon/liter of fuel
    private double totalCost; // Total amount paid for the fuel purchase

    // Constructors - initialize all fields when creating a new Record
    public Record(String date, String brand, int mileage, double cost, double totalCost) {
        this.date = date;      // Assign parameter to instance variable
        this.brand = brand;         //
        this.mileage = mileage;     //
        this.cost = cost;           //
        this.totalCost = totalCost; //
    }

    // Getters - provide read-only access to private fields
    public String getDate() { return date; }    // Returns the date of the fuel purchase
    public String getBrand() { return brand; }  // Returns the gas station brand/name

    public int getMileage() { return mileage; } // Returns the vehicle mileage at time of refill

    public double getCost() { return cost; }    // Returns the cost per gallon/liter
    public double getTotalCost() { return totalCost; } // Returns the total cost of the purchase

    // Setters - provide write access to private fields
    public void setDate(String date) { this.date = date; } // Sets a new date for the record
    public void setBrand(String brand) { this.brand = brand; } // Sets a new gas station brand

    public void setMileage(int mileage) { this.mileage = mileage; } // Sets a new mileage value

    public void setCost(double cost) { this.cost = cost; } // Sets a new cost per gallon
    public void setTotalCost(double totalCost) { this.totalCost = totalCost; }  // Sets new total cost
}
