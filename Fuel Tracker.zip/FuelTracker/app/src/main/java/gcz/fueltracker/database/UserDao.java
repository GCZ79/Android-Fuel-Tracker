package gcz.fueltracker.database;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao // @Dao annotation marks this interface as a Room Data Access Object
public interface UserDao {

    // @Query annotation: Defines custom SQL query
    @Query("SELECT * FROM users WHERE username = :username LIMIT 1")
    User getUserByUsername(String username);

    // Get all users
    @Query("SELECT * FROM users")
    List<User> getAllUsers();

    // Room generates SQL INSERT statement
    @Insert
    void insertUser(User user);

    // Room generates SQL UPDATE statement
    @Update
    void updateUser(User user);

    // Delete a user
    @Delete
    void deleteUser(User user);

}
