package gcz.fueltracker;

import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter;
import com.github.mikephil.charting.formatter.ValueFormatter;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import gcz.fueltracker.database.AppDatabase;
import gcz.fueltracker.database.DatabaseClient;
import gcz.fueltracker.database.FuelRefill;
import gcz.fueltracker.database.FuelRefillDao;
import gcz.fueltracker.database.User;

/** Fragment that displays comprehensive fuel tracking statistics including:
 * - Monthly expense trends (bar chart)
 * - Miles driven per month (bar chart)
 * - Average MPG over time (bar chart)
 * - Summary statistics (total spent, average costs, fuel efficiency metrics)
 * - Year filter to manage data across multiple years
 */
public class StatisticsFragment extends Fragment {

    private static final String TAG = "StatisticsFragment";

    // Bundle argument keys for passing user data
    private static final String ARG_USERNAME = "username";

    // Chart animation duration in milliseconds
    private static final int CHART_ANIMATION_DURATION = 1000;

    // Bar width as fraction of available space (0-1)
    private static final float CHART_BAR_WIDTH = 0.9f;

    // Special constant for "All Years" filter option
    private static final String ALL_YEARS = "All Years";

    // Current username whose statistics are being displayed
    private String currentUsername;

    // Currently selected year for filtering (or ALL_YEARS)
    private String selectedYear = ALL_YEARS;

    // Chart UI components
    private Spinner yearSpinner;        // Year filter spinner
    private BarChart barChart;          // Monthly expenses chart
    private BarChart barChartMiles;     // Monthly miles driven chart
    private BarChart barChartMPG;       // Monthly average MPG chart


    // Summary statistics text views
    private TextView textTotalSpent;           // Total Spent
    private TextView textAverageMonthly;       // Average monthly expense
    private TextView textTotalRefills;         // Number of refills
    private TextView textAverageCostPerGallon; // Average cost per gallon
    private TextView textDistanceRefills;      // Distance between refills
    private TextView textCostPerMile;          // Cost per mile
    private TextView textFuelConsumed;         // Total fuel consumed

    // Cached list of all fuel refill records, sorted chronologically
    private List<FuelRefill> allRecords = new ArrayList<>();

    // Filtered records based on selected year
    private List<FuelRefill> filteredRecords = new ArrayList<>();

    public StatisticsFragment() {
        // Required empty public constructor
    }

    // Create new instance of StatisticsFragment
    public static StatisticsFragment newInstance(User user) {
        StatisticsFragment fragment = new StatisticsFragment();
        Bundle args = new Bundle(); // Create bundle for arguments

        // Store only username for database queries
        args.putString(ARG_USERNAME, user.getUsername());

        // Attach arguments to fragment
        fragment.setArguments(args);
        return fragment;
    }

    // Retrieves username from arguments for database queries
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState); // Call superclass implementation first

        // Retrieve username from arguments
        if (getArguments() != null) {
            currentUsername = getArguments().getString(ARG_USERNAME);
        } else { // Log error
            Log.e(TAG, "No arguments provided to fragment");
        }
    }

    // Creates and initializes the fragment's view hierarchy
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the XML layout file into View objects
        View view = inflater.inflate(R.layout.fragment_statistics, container, false);

        // Initialize year filter spinner
        yearSpinner = view.findViewById(R.id.yearSpinner);

        // Initialize chart views
        barChart = view.findViewById(R.id.barChartMonthlyExpenses);
        barChartMiles = view.findViewById(R.id.barChartMonthlyMiles);
        barChartMPG = view.findViewById(R.id.barChartMPG);

        // Initialize summary statistic text views
        textTotalSpent = view.findViewById(R.id.textTotalSpent);
        textAverageMonthly = view.findViewById(R.id.textAverageMonthly);
        textTotalRefills = view.findViewById(R.id.textTotalRefills);
        textAverageCostPerGallon = view.findViewById(R.id.textAverageCostPerGallon);
        textDistanceRefills = view.findViewById(R.id.textDistanceRefills);
        textCostPerMile = view.findViewById(R.id.textCostPerMile);
        textFuelConsumed = view.findViewById(R.id.textFuelConsumed);

        // Load data from database and populate all charts and statistics
        loadDataAndUpdateChart();

        return view; // Return the fully configured view hierarchy
    }

    /** Attempts to parse a date string using multiple common date formats.
     * Supported formats:
     * - yyyy-MM-dd          (e.g., "2024-03-15")
     * - yyyy-MM-dd HH:mm    (e.g., "2024-03-15 14:30")
     * - yyyy-MM-dd H:mm     (e.g., "2024-03-15 2:30")
     * - yyyy-MM-dd HH:mm:ss (e.g., "2024-03-15 14:30:45")
     * - M/d/yyyy HH:mm:ss a (e.g., "3/15/2024 02:30:45 PM")
     * - M/d/yyyy h:mm:ss a  (e.g., "3/15/2024 2:30:45 PM")
     */
    private Date parseFlexibleDate(String input) {
        if (input == null || input.trim().isEmpty()) {
            return null;
        }

        // List of supported date formats, tried in order
        String[] patterns = {
                "yyyy-MM-dd",
                "yyyy-MM-dd HH:mm",
                "yyyy-MM-dd H:mm",
                "yyyy-MM-dd HH:mm:ss",
                "M/d/yyyy HH:mm:ss a",
                "M/d/yyyy h:mm:ss a"
        };

        // Try each pattern until one succeeds
        for (String pattern : patterns) {
            try {
                return new SimpleDateFormat(pattern, Locale.US).parse(input);
            } catch (Exception ignored) {
                // Continue to next pattern
            }
        }

        // Log error if all patterns fail
        Log.e(TAG, "Unrecognized date format: " + input);
        return null;
    }

    /** Loads fuel refill data from the database on a background thread,
     * sorts the records chronologically, extracts available years,
     * sets up the year filter, then updates all charts and statistics on the UI thread.
     * This method is called when the fragment is created and when it resumes.
     */
    private void loadDataAndUpdateChart() {
        // Verify currentUsername is not null
        if (currentUsername == null) {
            Log.e(TAG, "currentUsername is null, cannot load data");
            return;
        }

        // Get database instance
        AppDatabase db = DatabaseClient.getInstance(requireContext());
        FuelRefillDao dao = db.fuelRefillDao();

        // Execute database query on background thread
        new Thread(() -> {
            List<FuelRefill> records = dao.getRefillsForUser(currentUsername);

            if (records != null) {
                // Sort records by timestamp (oldest to newest)
                // Important for calculating miles driven and MPG correctly
                records.sort((r1, r2) -> {
                    Date d1 = parseFlexibleDate(r1.getTimestamp());
                    Date d2 = parseFlexibleDate(r2.getTimestamp());

                    // Handle null dates
                    if (d1 == null || d2 == null) {
                        return 0;
                    }

                    return d1.compareTo(d2);
                });

                // Update cached records
                allRecords = records;

                // Extract available years from records
                Set<String> yearsSet = extractYearsFromRecords(records);
                List<String> yearsList = new ArrayList<>(yearsSet);
                yearsList.sort((y1, y2) -> {
                    // Sort years in descending order (newest first)
                    if (y1.equals(ALL_YEARS)) return -1;
                    if (y2.equals(ALL_YEARS)) return 1;
                    return y2.compareTo(y1);
                });

                // Update UI on main thread
                requireActivity().runOnUiThread(() -> {
                    setupYearSpinner(yearsList);
                    applyYearFilter();
                    updateAllChartsAndStats();
                });
            } else {
                Log.e(TAG, "Records is null - database query failed");
            }
        }).start();
    }

    // Extract unique years from all refill records
    private Set<String> extractYearsFromRecords(List<FuelRefill> records) {
        Set<String> years = new HashSet<>();
        SimpleDateFormat yearFormat = new SimpleDateFormat("yyyy", Locale.US);

        // Always include "All Years" option
        years.add(ALL_YEARS);

        // Extract unique years from records
        for (FuelRefill refill : records) {
            Date date = parseFlexibleDate(refill.getTimestamp());
            if (date != null) {
                years.add(yearFormat.format(date));
            }
        }

        return years;
    }

    // Setup the year filter spinner with available years
    private void setupYearSpinner(List<String> years) {
        // Create adapter with year options
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                requireContext(),
                android.R.layout.simple_spinner_item,
                years
        );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        yearSpinner.setAdapter(adapter);

        // Set up selection listener
        yearSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectedYear = years.get(position);
                Log.d(TAG, "Year filter changed to: " + selectedYear);

                // Apply filter and refresh charts
                applyYearFilter();
                updateAllChartsAndStats();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Keep current selection
            }
        });
    }

    // Apply year filter to records
    private void applyYearFilter() {
        if (selectedYear.equals(ALL_YEARS)) {
            // Show all records
            filteredRecords = new ArrayList<>(allRecords);
            Log.d(TAG, "Showing all years: " + filteredRecords.size() + " records");
        } else {
            // Filter by selected year
            filteredRecords = filterRecordsByYear(allRecords, selectedYear);
            Log.d(TAG, "Filtered to year " + selectedYear + ": " + filteredRecords.size() + " records");
        }
    }

    // Filter records by specific year
    private List<FuelRefill> filterRecordsByYear(List<FuelRefill> records, String year) {
        List<FuelRefill> filtered = new ArrayList<>();
        SimpleDateFormat yearFormat = new SimpleDateFormat("yyyy", Locale.US);

        for (FuelRefill refill : records) {
            Date date = parseFlexibleDate(refill.getTimestamp());
            if (date != null) {
                String recordYear = yearFormat.format(date);
                if (recordYear.equals(year)) {
                    filtered.add(refill);
                }
            }
        }

        return filtered;
    }

    // Update all charts and statistics with filtered data
    private void updateAllChartsAndStats() {
        updateChart();
        updateMilesChart();
        updateMPGChart();
        updateSummaryStatistics();
    }

    // ======================
    // Chart Update Methods
    // ======================

    /** Updates the monthly expenses bar chart.
     * Shows total fuel costs grouped by month in chronological order.
     * - Blue bars representing dollar amounts
     * - X-axis shows month labels (e.g., "Jan 2025")
     * - Y-axis shows dollar amounts
     * - Values displayed on top of each bar (no decimals to declutter)
     */
    private void updateChart() {
        // Handle empty data case
        if (filteredRecords.isEmpty()) {
            barChart.clear();
            barChart.setNoDataText("No fuel records available");
            barChart.invalidate();
            return;
        }

        // Group all expenses by month
        Map<String, Float> monthlyExpenses = groupExpensesByMonth();

        // Convert map to chart entries
        List<BarEntry> entries = new ArrayList<>();
        List<String> labels = new ArrayList<>();
        int index = 0;

        for (Map.Entry<String, Float> entry : monthlyExpenses.entrySet()) {
            entries.add(new BarEntry(index, entry.getValue()));
            labels.add(entry.getKey());
            index++;
        }

        // Configure dataset appearance
        BarDataSet dataSet = new BarDataSet(entries, "Monthly Expenses");
        dataSet.setColor(Color.rgb(41, 128, 185));  // blue
        dataSet.setValueTextSize(9f);
        dataSet.setValueTextColor(Color.BLACK);

        // Format values as currency (e.g., "$150")
        dataSet.setValueFormatter(new ValueFormatter() {
            @Override
            public String getFormattedValue(float value) {
                return "$" + String.format(Locale.US, "%.0f", value);
            }
        });

        // Apply data to chart
        BarData data = new BarData(dataSet);
        data.setBarWidth(CHART_BAR_WIDTH);
        barChart.setData(data);

        // Disable description label
        barChart.getDescription().setEnabled(false);

        // Disable legend (not needed with single dataset)
        barChart.getLegend().setEnabled(false);

        // Enable bar fitting and animation
        barChart.setFitBars(true);
        barChart.animateY(CHART_ANIMATION_DURATION);

        // Configure X axis (months)
        XAxis xAxis = barChart.getXAxis();
        xAxis.setValueFormatter(new IndexAxisValueFormatter(labels));
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setGranularity(1f);
        xAxis.setGranularityEnabled(true);
        xAxis.setDrawGridLines(false);
        xAxis.setLabelRotationAngle(-15); // Angle labels for better readability

        // Configure Y axis (dollar amounts)
        YAxis yAxis = barChart.getAxisLeft();
        yAxis.setAxisMinimum(0f);
        yAxis.setDrawGridLines(true);
        yAxis.setValueFormatter(new ValueFormatter() {
            @Override
            public String getFormattedValue(float value) {
                return "$" + (int)value;
            }
        });

        // Disable right Y axis (not needed)
        barChart.getAxisRight().setEnabled(false);

        // Refresh chart display
        barChart.invalidate();
    }

    /** Updates the monthly miles driven bar chart.
     * Calculates miles driven between consecutive refills, grouped by month.
     * - Green bars representing miles calculated from odometer differences
     */
    private void updateMilesChart() {
        // Handle empty data case
        if (filteredRecords.isEmpty()) {
            barChartMiles.clear();
            barChartMiles.setNoDataText("No mileage data available");
            barChartMiles.invalidate();
            return;
        }

        // Calculate miles driven per month
        Map<String, Float> monthlyMiles = groupMilesByMonth();

        // Convert map to chart entries
        List<BarEntry> entries = new ArrayList<>();
        List<String> labels = new ArrayList<>();
        int index = 0;

        for (Map.Entry<String, Float> entry : monthlyMiles.entrySet()) {
            entries.add(new BarEntry(index, entry.getValue()));
            labels.add(entry.getKey());
            index++;
        }

        // Configure dataset appearance
        BarDataSet dataSet = new BarDataSet(entries, "Miles Driven");
        dataSet.setColor(Color.rgb(39, 174, 96));  // Green
        dataSet.setValueTextSize(9f);
        dataSet.setValueTextColor(Color.BLACK);

        // Format values as whole numbers (e.g., "350")
        dataSet.setValueFormatter(new ValueFormatter() {
            @Override
            public String getFormattedValue(float value) {
                return String.format(Locale.US, "%.0f", value);
            }
        });

        // Apply data to chart
        BarData data = new BarData(dataSet);
        data.setBarWidth(CHART_BAR_WIDTH);
        barChartMiles.setData(data);

        // Disable description and legend
        barChartMiles.getDescription().setEnabled(false);
        barChartMiles.getLegend().setEnabled(false);

        // Enable bar fitting and animation
        barChartMiles.setFitBars(true);
        barChartMiles.animateY(CHART_ANIMATION_DURATION);

        // Configure X axis (months)
        XAxis xAxis = barChartMiles.getXAxis();
        xAxis.setValueFormatter(new IndexAxisValueFormatter(labels));
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setGranularity(1f);
        xAxis.setGranularityEnabled(true);
        xAxis.setDrawGridLines(false);
        xAxis.setLabelRotationAngle(-15); // Angle labels for better readability

        // Configure Y axis (miles)
        YAxis yAxis = barChartMiles.getAxisLeft();
        yAxis.setAxisMinimum(0f);
        yAxis.setDrawGridLines(true);

        // Disable right Y axis
        barChartMiles.getAxisRight().setEnabled(false);

        // Refresh chart display
        barChartMiles.invalidate();
    }

    /** Updates the average MPG (Miles Per Gallon) bar chart.
     * Calculation method:
     * - For each pair of consecutive refills:
     *   - Miles = current_odometer - previous_odometer
     *   - Gallons = current_refill_cost / current_price_per_gallon
     *   - MPG = miles / gallons
     * - Average all MPG values within each month
     * Note: This assumes the fuel purchased at the current refill was used
     * to drive the miles since the previous refill. This is an approximation
     * since technically those miles were driven on the previous tank.
     * Requires at least 2 refill records to calculate.
     */
    private void updateMPGChart() {
        // Need at least 2 records to calculate MPG
        if (filteredRecords.size() < 2) {
            barChartMPG.clear();
            barChartMPG.setNoDataText("Need at least 2 refills to calculate MPG");
            barChartMPG.invalidate();
            return;
        }

        // Maps to accumulate MPG data by month
        Map<String, Float> monthlyMPG = new LinkedHashMap<>();
        Map<String, Integer> monthCounts = new LinkedHashMap<>();
        SimpleDateFormat monthFormat = new SimpleDateFormat("MMM yyyy", Locale.US);

        // Iterate through consecutive refill pairs
        for (int i = 1; i < filteredRecords.size(); i++) {
            FuelRefill previousRefill = filteredRecords.get(i - 1);
            FuelRefill currentRefill = filteredRecords.get(i);

            // Calculate gallons purchased at current refill
            float gallons = currentRefill.getTotalCost() / currentRefill.getCostPerGallon();

            // Calculate miles driven since previous refill
            int milesDriven = currentRefill.getMileage() - previousRefill.getMileage();

            // Skip invalid data (negative miles or zero gallons)
            if (milesDriven <= 0 || gallons <= 0) {
                continue;
            }

            // Calculate MPG for this interval
            float mpg = milesDriven / gallons;

            // Get the month of the current refill
            Date refillDate = parseFlexibleDate(currentRefill.getTimestamp());
            if (refillDate == null) {
                continue;
            }
            String monthKey = monthFormat.format(refillDate);

            // Accumulate MPG values for this month
            Float currentMPGTotal = monthlyMPG.get(monthKey);
            if (currentMPGTotal == null) {
                currentMPGTotal = 0f;
            }
            monthlyMPG.put(monthKey, currentMPGTotal + mpg);

            // Count number of refill intervals in this month
            Integer count = monthCounts.get(monthKey);
            if (count == null) {
                count = 0;
            }
            monthCounts.put(monthKey, count + 1);
        }

        // Calculate average MPG per month
        Map<String, Float> averageMPG = new LinkedHashMap<>();
        for (String month : monthlyMPG.keySet()) {
            Float totalMPG = monthlyMPG.get(month);
            if (totalMPG == null) {
                totalMPG = 0f;
            }

            Integer count = monthCounts.get(month);
            if (count == null || count == 0) {
                count = 1; // Prevent division by zero
            }

            averageMPG.put(month, totalMPG / count);
        }

        // Convert map to chart entries
        List<BarEntry> entries = new ArrayList<>();
        List<String> labels = new ArrayList<>();
        int index = 0;

        for (Map.Entry<String, Float> entry : averageMPG.entrySet()) {
            entries.add(new BarEntry(index, entry.getValue()));
            labels.add(entry.getKey());
            index++;
        }

        // Configure dataset appearance
        BarDataSet dataSet = new BarDataSet(entries, "MPG");
        dataSet.setColor(Color.rgb(243, 156, 18));  // Orange
        dataSet.setValueTextSize(9f);
        dataSet.setValueTextColor(Color.BLACK);

        // Format values with one decimal place (e.g., "28.5")
        dataSet.setValueFormatter(new ValueFormatter() {
            @Override
            public String getFormattedValue(float value) {
                return String.format(Locale.US, "%.1f", value);
            }
        });

        // Apply data to chart
        BarData data = new BarData(dataSet);
        data.setBarWidth(CHART_BAR_WIDTH);
        barChartMPG.setData(data);

        // Disable description and legend
        barChartMPG.getDescription().setEnabled(false);
        barChartMPG.getLegend().setEnabled(false);

        // Enable bar fitting and animation
        barChartMPG.setFitBars(true);
        barChartMPG.animateY(CHART_ANIMATION_DURATION);

        // Configure X axis (months)
        XAxis xAxis = barChartMPG.getXAxis();
        xAxis.setValueFormatter(new IndexAxisValueFormatter(labels));
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setGranularity(1f);
        xAxis.setGranularityEnabled(true);
        xAxis.setDrawGridLines(false);
        xAxis.setLabelRotationAngle(-15); // Angle labels for better readability

        // Configure Y axis (MPG)
        YAxis yAxis = barChartMPG.getAxisLeft();
        yAxis.setAxisMinimum(0f);
        yAxis.setDrawGridLines(true);

        // Disable right Y axis
        barChartMPG.getAxisRight().setEnabled(false);

        // Refresh chart display
        barChartMPG.invalidate();
    }

    // ========================================
    // Helper Methods for Data Aggregation
    // ========================================

    /** Groups fuel expenses by month and returns them in chronological order.
     * Uses filteredRecords for calculation.
     * 1. Iterate through all filtered refill records
     * 2. Parse timestamp and extract month/year
     * 3. Sum total costs for each month
     * 4. Sort months chronologically
     * @return LinkedHashMap with month labels (e.g., "Jan 2025") as keys
     *         and total expenses as values, in chronological order
     */
    private Map<String, Float> groupExpensesByMonth() {
        Map<String, Float> monthlyExpenses = new HashMap<>();
        SimpleDateFormat monthFormat = new SimpleDateFormat("MMM yyyy", Locale.US);

        // Sum expenses for each month
        for (FuelRefill refill : filteredRecords) {
            Date refillDate = parseFlexibleDate(refill.getTimestamp());
            if (refillDate == null) {
                continue; // Skip records with invalid dates
            }

            String monthKey = monthFormat.format(refillDate);

            // Add to existing total or initialize
            Float currentTotal = monthlyExpenses.get(monthKey);
            if (currentTotal == null) {
                currentTotal = 0f;
            }
            monthlyExpenses.put(monthKey, currentTotal + refill.getTotalCost());
        }

        // Sort entries by date
        List<Map.Entry<String, Float>> sortedEntries = new ArrayList<>(monthlyExpenses.entrySet());
        sortedEntries.sort((entry1, entry2) -> {
            try {
                Date date1 = monthFormat.parse(entry1.getKey());
                Date date2 = monthFormat.parse(entry2.getKey());

                if (date1 != null && date2 != null) {
                    return date1.compareTo(date2);
                }
            } catch (ParseException e) {
                Log.e(TAG, "Error parsing month for sorting", e);
            }
            return 0;
        });

        // Return as LinkedHashMap to preserve chronological order
        Map<String, Float> result = new LinkedHashMap<>();
        for (Map.Entry<String, Float> entry : sortedEntries) {
            result.put(entry.getKey(), entry.getValue());
        }
        return result;
    }

    /** Groups miles driven by month based on odometer differences between
     * consecutive refills. Uses filteredRecords for calculation.
     * 1. Iterate through pairs of consecutive filtered refills
     * 2. Calculate odometer difference (miles driven)
     * 3. Assign these miles to the month of the current (later) refill
     * 4. Sum miles for each month
     * 5. Sort months chronologically
     * Note: Negative mileage differences are treated as 0 (data error protection)
     * @return LinkedHashMap with month labels as keys and total miles as values,
     *         in chronological order
     */
    private Map<String, Float> groupMilesByMonth() {
        Map<String, Float> monthlyMiles = new HashMap<>();
        SimpleDateFormat monthFormat = new SimpleDateFormat("MMM yyyy", Locale.US);

        // Need at least 2 records to calculate miles driven
        if (filteredRecords.size() < 2) {
            return monthlyMiles;
        }

        // Calculate miles driven between each pair of consecutive refills
        for (int i = 1; i < filteredRecords.size(); i++) {
            FuelRefill previousRefill = filteredRecords.get(i - 1);
            FuelRefill currentRefill = filteredRecords.get(i);

            // Calculate odometer difference
            int milesDriven = currentRefill.getMileage() - previousRefill.getMileage();

            // Handle invalid data (negative miles indicate error)
            if (milesDriven < 0) {
                milesDriven = 0;
            }

            // Get month of current refill
            Date refillDate = parseFlexibleDate(currentRefill.getTimestamp());
            if (refillDate == null) {
                continue; // Skip records with invalid dates
            }
            String monthKey = monthFormat.format(refillDate);

            // Accumulate miles for this month
            Float currentTotal = monthlyMiles.get(monthKey);
            if (currentTotal == null) {
                currentTotal = 0f;
            }
            monthlyMiles.put(monthKey, currentTotal + milesDriven);
        }

        // Sort entries by date
        List<Map.Entry<String, Float>> sortedEntries = new ArrayList<>(monthlyMiles.entrySet());
        sortedEntries.sort((entry1, entry2) -> {
            try {
                Date date1 = monthFormat.parse(entry1.getKey());
                Date date2 = monthFormat.parse(entry2.getKey());
                return date1 != null && date2 != null ? date1.compareTo(date2) : 0;
            } catch (ParseException e) {
                Log.e(TAG, "Error parsing month for sorting", e);
            }
            return 0;
        });

        // Return as LinkedHashMap to preserve chronological order
        Map<String, Float> result = new LinkedHashMap<>();
        for (Map.Entry<String, Float> entry : sortedEntries) {
            result.put(entry.getKey(), entry.getValue());
        }
        return result;
    }

    /** Calculates total gallons of fuel consumed across all filtered refills.
     * For each refill, gallons = totalCost / costPerGallon
     * @return Total gallons consumed
     */
    private float calculateTotalFuelConsumed() {
        float totalGallons = 0f;

        for (FuelRefill refill : filteredRecords) {
            // Calculate gallons from cost and price per gallon
            totalGallons += refill.getTotalCost() / refill.getCostPerGallon();
        }

        return totalGallons;
    }

    /** Calculates average distance (in miles) driven between refills.
     * 1. Calculate odometer difference for each consecutive pair
     * 2. Sum all positive differences
     * 3. Divide by number of intervals
     * @return Average miles between refills, or 0 if insufficient data
     */
    private float calculateAverageDistanceBetweenRefills() {
        // Need at least 2 records to calculate distance
        if (filteredRecords.size() < 2) {
            return 0f;
        }

        int totalMiles = 0;
        int validIntervals = 0;

        // Sum up distances between consecutive refills
        for (int i = 1; i < filteredRecords.size(); i++) {
            int milesDriven = filteredRecords.get(i).getMileage() - filteredRecords.get(i - 1).getMileage();

            // Only include valid (non-negative) distances
            if (milesDriven >= 0) {
                totalMiles += milesDriven;
                validIntervals++;
            }
        }

        // Calculate average
        return validIntervals > 0 ? (float) totalMiles / validIntervals : 0f;
    }

    /** Calculates cost per mile driven.
     * Uses the PREVIOUS refill's cost for the miles driven between refills,
     * since those miles were driven on the fuel from the previous fill-up.
     * 1. For each consecutive pair of refills:
     *    - Calculate miles = current_odometer - previous_odometer
     *    - Use cost from PREVIOUS refill (that fuel powered those miles)
     * 2. Sum all costs and miles
     * 3. Divide total cost by total miles
     * @return Average cost per mile, or 0 if insufficient data
     */
    private float calculateCostPerMile() {
        // Need at least 2 records to calculate
        if (filteredRecords.size() < 2) {
            return 0f;
        }

        float totalCost = 0f;
        int totalMiles = 0;

        // Iterate through consecutive refill pairs
        for (int i = 1; i < filteredRecords.size(); i++) {
            FuelRefill previousRefill = filteredRecords.get(i - 1);
            FuelRefill currentRefill = filteredRecords.get(i);

            // Calculate miles driven between refills
            int milesDriven = currentRefill.getMileage() - previousRefill.getMileage();

            // Skip invalid data (negative or zero miles)
            if (milesDriven <= 0) {
                continue;
            }

            // CRITICAL FIX: Use PREVIOUS refill cost, since those miles
            // were driven on the fuel from that previous fill-up
            totalCost += previousRefill.getTotalCost();
            totalMiles += milesDriven;
        }

        // Calculate average cost per mile
        return totalMiles > 0 ? totalCost / totalMiles : 0f;
    }

    /** Updates all summary statistic text views with calculated values.
     * Calculates and displays:
     * - Total amount spent on fuel
     * - Average monthly fuel expense
     * - Total number of refills
     * - Average cost per gallon
     * - Average distance between refills
     * - Cost per mile driven
     * - Total gallons consumed
     */
    private void updateSummaryStatistics() {
        // Calculate basic totals
        float totalSpent = 0f;
        float totalCostPerGallon = 0f;

        for (FuelRefill refill : filteredRecords) {
            totalSpent += refill.getTotalCost();
            totalCostPerGallon += refill.getCostPerGallon();
        }

        // Calculate average monthly expense
        Map<String, Float> monthlyExpenses = groupExpensesByMonth();
        int monthCount = monthlyExpenses.size();
        float averageMonthly = monthCount > 0 ? totalSpent / monthCount : 0f;

        // Calculate average cost per gallon
        float averageCostPerGallon = !filteredRecords.isEmpty()
                ? totalCostPerGallon / filteredRecords.size()
                : 0f;

        // Calculate distance and efficiency metrics
        float averageDistance = calculateAverageDistanceBetweenRefills();
        float costPerMile = calculateCostPerMile();
        float totalFuel = calculateTotalFuelConsumed();

        // Update UI with formatted values
        textTotalSpent.setText(String.format(Locale.US, "Total Spent: $%.2f", totalSpent));
        textAverageMonthly.setText(String.format(Locale.US, "Average Monthly: $%.2f", averageMonthly));
        textTotalRefills.setText(String.format(Locale.US, "Total Refills: %d", filteredRecords.size()));
        textAverageCostPerGallon.setText(String.format(Locale.US, "Average Cost/Gallon: $%.2f", averageCostPerGallon));
        textDistanceRefills.setText(String.format(Locale.US, "Average Distance Between Refills: %.0f mi", averageDistance));
        textCostPerMile.setText(String.format(Locale.US, "Cost per Mile: $%.2f", costPerMile));
        textFuelConsumed.setText(String.format(Locale.US, "Total Gallons Consumed: %.2f", totalFuel));
    }

    /** Called when fragment becomes visible to the user.
     * Reloads data to ensure statistics are up-to-date if new records
     * were added while the fragment was paused.
     */
    @Override
    public void onResume() {
        super.onResume();
        loadDataAndUpdateChart();
    }
}