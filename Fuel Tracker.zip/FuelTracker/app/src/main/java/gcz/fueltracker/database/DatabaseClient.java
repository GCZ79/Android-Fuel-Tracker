package gcz.fueltracker.database;

import android.content.Context;

import androidx.room.Room;

public class DatabaseClient {
    private static AppDatabase instance; // Static variable holding the single instance of AppDatabase
    private static final String DB_NAME = "fueltracker.db"; // Constant for database filename

    // Public static method to get the database instance (singleton accessor)
    public static synchronized AppDatabase getInstance(Context context) {
        if (instance == null) {
            instance = Room.databaseBuilder(
                            context.getApplicationContext(), // Use application context (avoids memory leaks)
                            AppDatabase.class,               // Room uses this to generate the database
                            DB_NAME                          // Database filename constant
                    )
                    .fallbackToDestructiveMigration()        // Handle schema changes during development
                    .build();                                // Builds and returns the database instance
        }
        return instance;                         // Returns the existing instance (or newly created one)
    }
}