package gcz.fueltracker;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;
import java.util.Locale;

import gcz.fueltracker.database.FuelRefill;

public class FuelRefillAdapter extends RecyclerView.Adapter<FuelRefillAdapter.ViewHolder> {

    private final List<FuelRefill> records; // List to hold the fuel refill records to display
    private final OnRecordActionListener listener; // Listener to handle edit/delete actions on records


    // Interface definition for callback methods when user interacts with a record
    public interface OnRecordActionListener {
        void onEdit(FuelRefill refill); // Called when user wants to edit a specific fuel refill record
        void onDelete(FuelRefill refill);// Called when user wants to delete a specific fuel refill record
    }

    // Constructor that initializes the adapter with data and a listener
    public FuelRefillAdapter(List<FuelRefill> records, OnRecordActionListener listener) {
        this.records = records;   // Store the passed records list
        this.listener = listener; // Store the passed listener for callback handling
    }

    // Called when RecyclerView needs a new ViewHolder (creates the visual item layout)
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate the layout for a single list item from XML
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_record, parent, false);
        // Create and return a new ViewHolder containing this inflated view
        return new ViewHolder(view);
    }

    // Called to bind data to a specific position in the RecyclerView
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        // Get the FuelRefill object at the current position
        FuelRefill refill = records.get(position);

        // Set the date text from the refill's timestamp
        holder.textDate.setText(refill.getTimestamp());
        // Set the gas station brand/name
        holder.textBrand.setText(refill.getStation());
        // Set the vehicle mileage at time of refill
        holder.textMileage.setText(String.valueOf(refill.getMileage()));
        // Format and set the cost per gallon with dollar sign and 2 decimals
        holder.textCost.setText(String.format(Locale.US, "$%.2f", refill.getCostPerGallon()));
        // Format and set the total cost with dollar sign and 2 decimals
        holder.textTotal.setText(String.format(Locale.US, "$%.2f", refill.getTotalCost()));

        // Set up click listener for the edit button
        holder.buttonEdit.setOnClickListener(v -> {
            // Notify listener about edit action, passing the specific refill record
            if (listener != null) listener.onEdit(refill);
        });

        // Set up click listener for the delete button
        holder.buttonDelete.setOnClickListener(v -> {
            // Notify listener about delete action, passing the specific refill record
            if (listener != null) listener.onDelete(refill);
        });
    }

    // Returns the total number of items in the data set
    @Override
    public int getItemCount() {
        return records.size();
    }

    // Inner ViewHolder class that holds references to all views in a list item
    public static class ViewHolder extends RecyclerView.ViewHolder {
        // TextViews for displaying refill data
        TextView textDate;
        TextView textBrand;
        TextView textMileage;
        TextView textCost;
        TextView textTotal;
        // Buttons for user actions on each record
        ImageButton buttonEdit;
        ImageButton buttonDelete;

        // Constructor that finds and stores references to all views in the item layout
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            // Find each view by its ID from the inflated layout
            textDate = itemView.findViewById(R.id.textDate);
            textBrand = itemView.findViewById(R.id.textBrand);
            textMileage = itemView.findViewById(R.id.textMileage);
            textCost = itemView.findViewById(R.id.textCost);
            textTotal = itemView.findViewById(R.id.textTotal);
            buttonEdit = itemView.findViewById(R.id.buttonEdit);
            buttonDelete = itemView.findViewById(R.id.buttonDelete);
        }
    }
}