package gcz.fueltracker;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.google.android.material.slider.Slider;

import java.io.File;
import java.util.List;
import java.util.Locale;

import gcz.fueltracker.database.AppDatabase;
import gcz.fueltracker.database.DatabaseClient;
import gcz.fueltracker.database.FuelRefill;
import gcz.fueltracker.database.FuelRefillDao;
import gcz.fueltracker.database.User;

public class FuelRefillFragment extends Fragment {

    private static final String DB_NAME = "fueltracker.db"; // Database configuration
    private static final String TAG = "FuelRefillFragment"; // Logging tag for debugging

    private int lastMileage = 1;                            // Last recorded mileage from DB
    private float lastCost = 4.00f;                         // Last recorded cost per gallon
    private Runnable updateTotals;                          // Callback for real-time calculations
    private ImageButton selectedButton;                     // Currently selected gas station button
    private String selectedStationValue = "generic";        // Default station selection
    private User currentUser;                               // Current logged-in user
    private Slider sliderCost;                              // Cost per gallon slider
    private EditText editCurrentCost;                       // Cost per gallon text input
    private SimpleTextWatcher costTextWatcher;              // Text watcher for cost input

    public FuelRefillFragment() {
        // Required empty public constructor
    }

    public FuelRefillFragment(User user) {
        // Constructor with user parameter for initial setup
        this.currentUser = user;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Initialize ViewModel to persist data across configuration changes (e.g., rotation)
        FuelViewModel viewModel = new ViewModelProvider(this).get(FuelViewModel.class);

        // If currentUser is not set (e.g., after rotation), get from ViewModel
        if (currentUser == null) {
            currentUser = viewModel.getCurrentUser();
        } else {
            // If we have currentUser (from constructor), save it to ViewModel
            viewModel.setCurrentUser(currentUser);
        }

        // Load last refill data from database or use mock data
        if (doesDatabaseExist(requireContext()) && currentUser != null) {
            Log.d(TAG, "Database exists - loading last refill for user: " + currentUser.getUsername());
            loadLastMileageFromDB();
        } else {
            Log.d(TAG, "Database does not exist or user not set - using mock data");
            loadMockLastRefill();
        }
    }

    /* onCreateView:
     * 1. Inflates the fragment layout (R.layout.fragment_fuel_refill)
     * 2. Sets up gas station selection buttons with saved preferences
     * 3. Configures mileage input with slider/text field synchronization
     * 4. Sets up cost per gallon input with dynamic slider range
     * 5. Configures real-time calculation of total gallons
     * 6. Sets up save button with validation
     */
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        // Inflate the fragment layout from XML
        View view = inflater.inflate(R.layout.fragment_fuel_refill, container, false);

        // Initialize gas station selection buttons
        ImageButton img1 = view.findViewById(R.id.favorite1);
        ImageButton img2 = view.findViewById(R.id.favorite2);
        ImageButton img3 = view.findViewById(R.id.favorite3);
        ImageButton img4 = view.findViewById(R.id.generic);

        // Load user preferences saved in SharedPreferences
        android.content.SharedPreferences prefs = androidx.preference.PreferenceManager
                .getDefaultSharedPreferences(requireContext());
        String fav1 = prefs.getString("favorite_gas1", "generic");
        String fav2 = prefs.getString("favorite_gas2", "generic");
        String fav3 = prefs.getString("favorite_gas3", "generic");

        // Get currency settings for proper formatting
        String currencyCode = prefs.getString("favorite_currency", "USD");
        String currencySymbol = getCurrencySymbol(currencyCode);

        // Set appropriate logos for each gas station button
        img1.setImageResource(getLogoDrawable(fav1));
        img2.setImageResource(getLogoDrawable(fav2));
        img3.setImageResource(getLogoDrawable(fav3));
        img4.setImageResource(R.drawable.logo_generic);

        // Set default selection to generic station
        setSelected(img4, "generic");

        // Configure click listeners for station selection with dynamic cost loading
        img1.setOnClickListener(v -> selectStationAndLoadCost(view, fav1, img1));
        img2.setOnClickListener(v -> selectStationAndLoadCost(view, fav2, img2));
        img3.setOnClickListener(v -> selectStationAndLoadCost(view, fav3, img3));
        img4.setOnClickListener(v -> selectStationAndLoadCost(view, "generic", img4));

        // Display previous refill information
        TextView tvLastMileage = view.findViewById(R.id.last_mileage_value);
        tvLastMileage.setText(String.valueOf(lastMileage));

        TextView tvLastCost = view.findViewById(R.id.last_cost_value);
        tvLastCost.setText(String.format(Locale.getDefault(), "%s%.2f", currencySymbol, lastCost));

        // Mileage Input setup with dynamic slider range
        EditText editCurrentMileage = view.findViewById(R.id.editCurrentMileage);
        Slider sliderMileage = view.findViewById(R.id.sliderCurrentMileage);

        // Configure slider with reasonable bounds based on last mileage
        if (lastMileage <= 1) {                // new user
            sliderMileage.setValueFrom(1f);
            sliderMileage.setValueTo(200000f); // new user = sizeable mileage range
            sliderMileage.setValue(1f);
            editCurrentMileage.setText("1");
        } else {
            sliderMileage.setValueFrom(lastMileage);
            sliderMileage.setValueTo(lastMileage + 600f);
            sliderMileage.setValue(lastMileage);
            editCurrentMileage.setText(String.valueOf(lastMileage));
        }

        // Flag to prevent infinite update loops between slider and text field
        final boolean[] editingMileage = {false};

        // Sync slider changes to text field
        sliderMileage.addOnChangeListener((slider, value, fromUser) -> {
            if (editingMileage[0]) return; // Prevent recursion
            editingMileage[0] = true;
            editCurrentMileage.setText(String.valueOf((int) value)); // Convert to integer
            editingMileage[0] = false;
        });

        /* Synchronization Pattern:
         * - The slider and text field are bidirectionally synchronized
         * - A boolean flag prevents infinite update loops
         * - Slider changes update text field (rounded to integer)
         * - Text field changes update slider (with validation)
         * - This provides both precise (text) and quick (slider) input methods
         */

        // Sync text field changes to slider with validation
        editCurrentMileage.addTextChangedListener(new SimpleTextWatcher() {
            @Override
            public void afterTextChanged(android.text.Editable s) {
                if (editingMileage[0]) return; // Prevent recursion
                String str = s.toString();
                if (!str.isEmpty()) {
                    try {
                        editingMileage[0] = true;
                        float value = Float.parseFloat(str);
                        // Only update slider if value is within valid range
                        if (value >= sliderMileage.getValueFrom() && value <= sliderMileage.getValueTo()) {
                            sliderMileage.setValue(value);
                        }
                    } catch (Exception ignored) { // Invalid input
                    } finally {
                        editingMileage[0] = false;
                    }
                }
            }
        });

        // Setup cost per gallon slider with dynamic range based on station history
        setupCostSlider(view);

        // Calculation and Save setup
        TextView tvTotalGallons = view.findViewById(R.id.total_gallons_value);
        EditText editTotalCost = view.findViewById(R.id.total_cost_value);
        Button btnSave = view.findViewById(R.id.button_save);

        editTotalCost.setText("");  // Start with empty total cost
        btnSave.setEnabled(false);  // Disable button until user enters cost

        // Trigger calculations when total cost changes
        editTotalCost.addTextChangedListener(new SimpleTextWatcher() {
            @Override
            public void afterTextChanged(android.text.Editable s) {
                if (updateTotals != null) editTotalCost.post(updateTotals);
                // Enable Save button only if total cost has a value
                btnSave.setEnabled(!s.toString().trim().isEmpty());
            }
        });

        // Real-time calculation of total gallons based on cost inputs
        updateTotals = () -> {
            String costStr = editTotalCost.getText().toString().trim();
            EditText editCurrentCost = view.findViewById(R.id.editCurrentCost);
            String costPerGallonStr = editCurrentCost.getText().toString().trim();

            // Clear total gallons if either field is empty
            if (costStr.isEmpty() || costPerGallonStr.isEmpty()) {
                tvTotalGallons.setText(getString(R.string.n_a));
                return;
            }

            try {
                float totalCost = Float.parseFloat(costStr);
                float costPerGallon = Float.parseFloat(costPerGallonStr);

                // Prevent division by zero and calculate gallons
                if (costPerGallon > 0) {
                    float totalGallons = totalCost / costPerGallon;
                    tvTotalGallons.setText(String.format(Locale.US, "%.3f", totalGallons));
                } else {
                    tvTotalGallons.setText(getString(R.string.n_a));
                }
            } catch (NumberFormatException e) {
                tvTotalGallons.setText(getString(R.string.n_a));
            }
        };

        // Set up save button with data validation
        btnSave.setOnClickListener(v -> saveRefillData(editCurrentMileage,
                view.findViewById(R.id.editCurrentCost),
                editTotalCost, currencySymbol));

        return view;
    }

    // Select gas station and load last cost per gallon for that station from database
    private void selectStationAndLoadCost(View view, String station, ImageButton button) {
        setSelected(button, station);

        // Always set default 4.00 first as fallback
        lastCost = 4.00f;

        if (doesDatabaseExist(requireContext()) && currentUser != null) {
            new Thread(() -> {
                AppDatabase db = DatabaseClient.getInstance(requireContext());
                FuelRefillDao dao = db.fuelRefillDao();
                List<FuelRefill> refills = dao.getRefillsForUser(currentUser.getUsername());

                // Find the most recent refill at this station
                for (FuelRefill r : refills) {
                    if (r.getStation().equals(station)) {
                        lastCost = r.getCostPerGallon();
                        Log.d(TAG, "Loaded last cost for " + station + ": $" + lastCost);
                        break;
                    }
                }

                // Update slider on UI thread
                if (getActivity() != null) {
                    getActivity().runOnUiThread(() -> setupCostSlider(view));
                }
            }).start();
        } else {
            Log.d(TAG, "Using default cost for " + station);
            setupCostSlider(view);
        }
    }

    // Setup cost per gallon slider with dynamic range
    private void setupCostSlider(View view) {
        editCurrentCost = view.findViewById(R.id.editCurrentCost);
        sliderCost = view.findViewById(R.id.sliderCurrentCost);

        // Clear all existing listeners to prevent conflicts
        sliderCost.clearOnChangeListeners();
        if (costTextWatcher != null) {
            editCurrentCost.removeTextChangedListener(costTextWatcher);
        }

        // Round min and max to nearest 0.10 to ensure stepSize works properly
        float min = (float) (Math.floor((lastCost - 2f) * 10) / 10.0);
        if (min < 0.10f) min = 0.10f;
        float max = (float) (Math.ceil((lastCost + 2f) * 10) / 10.0);

        sliderCost.setValueFrom(min);
        sliderCost.setValueTo(max);
        sliderCost.setStepSize(0.10f);

        // Round lastCost to nearest 0.10
        float roundedLastCost = Math.round(lastCost * 10) / 10.0f;
        sliderCost.setValue(roundedLastCost);
        editCurrentCost.setText(String.format(Locale.US, "%.2f", roundedLastCost));

        // Flag to prevent infinite update loops between slider and text field
        final boolean[] editingCost = {false};

        // Sync slider changes to text field
        sliderCost.addOnChangeListener((slider, value, fromUser) -> {
            if (editingCost[0]) return; // Prevent recursion
            editingCost[0] = true;
            editCurrentCost.setText(String.format(Locale.US, "%.2f", value));
            editingCost[0] = false;
            // Trigger calculation updates
            if (updateTotals != null) updateTotals.run();
        });

        // Sync text field changes to slider with validation
        costTextWatcher = new SimpleTextWatcher() {
            @Override
            public void afterTextChanged(android.text.Editable s) {
                if (editingCost[0]) return; // Prevent recursion

                String str = s.toString().trim();

                // Always update totals first, even if field is empty or invalid
                if (updateTotals != null) {
                    editCurrentCost.post(updateTotals);
                }

                // Don't try to update slider if field is empty or just a decimal point
                if (str.isEmpty() || str.equals(".")) {
                    return;
                }

                try {
                    float value = Float.parseFloat(str);

                    // Ensure value is positive
                    if (value <= 0) {
                        return;
                    }

                    float from = sliderCost.getValueFrom();
                    float to = sliderCost.getValueTo();

                    // Only update slider if value is within range
                    if (value >= from && value <= to) {
                        editingCost[0] = true;
                        try {
                            // Round to nearest 0.10 to match step size
                            float roundedValue = Math.round(value * 10) / 10.0f;
                            sliderCost.setValue(roundedValue);
                        } catch (IllegalArgumentException e) {
                            // Ignore if slider can't be set to this value
                            // This can happen if the value doesn't align with step size
                        } catch (Exception e) {
                            // Catch any other exceptions
                        } finally {
                            editingCost[0] = false;
                        }
                    }
                } catch (NumberFormatException e) {
                    // Ignore invalid input during typing (e.g., "3." or incomplete numbers)
                }
            }
        };

        editCurrentCost.addTextChangedListener(costTextWatcher);
    }

    // Load last mileage from database for current user
    private void loadLastMileageFromDB() {
        if (doesDatabaseExist(requireContext()) && currentUser != null) {
            new Thread(() -> {
                AppDatabase db = DatabaseClient.getInstance(requireContext());
                FuelRefillDao dao = db.fuelRefillDao();
                FuelRefill lastRefill = dao.getLastRefill(currentUser.getUsername());
                if (lastRefill != null) {
                    lastMileage = lastRefill.getMileage();
                    Log.d(TAG, "Loaded last mileage from DB: " + lastMileage);
                }
            }).start();
        }
    }

    // Load mock data for testing when database is not available
    private void loadMockLastRefill() {
        lastMileage = 1;
        lastCost = 4.00f;
        Log.d(TAG, String.format("Using mock data - Mileage: %d, Cost: %.2f",
                lastMileage, lastCost));
    }

    // Validate and save refill data to persistent storage
    private void saveRefillData(EditText editCurrentMileage, EditText editCurrentCost,
                                EditText editTotalCost, String currencySymbol) {
        // Generate timestamp
        String timestamp = java.time.LocalDateTime.now()
                .format(java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"));

        String station = selectedStationValue;

        // Parse input values with error handling
        int currentMileage = 0;
        try {
            currentMileage = Integer.parseInt(editCurrentMileage.getText().toString());
        } catch (NumberFormatException ignored) { }

        float costPerGallon = 0f;
        try {
            costPerGallon = Float.parseFloat(editCurrentCost.getText().toString());
        } catch (NumberFormatException ignored) { }

        float totalCost = 0f;
        try {
            totalCost = Float.parseFloat(editTotalCost.getText().toString());
        } catch (NumberFormatException ignored) { }

        // Create the refill object
        final int finalCurrentMileage = currentMileage;
        final float finalCostPerGallon = costPerGallon;
        final float finalTotalCost = totalCost;

        /* Mileage Validation Rules:
         * 1. New mileage < last mileage: Show warning (most likely a user's typo)
         * 2. New mileage = last mileage: Show confirmation (unusual but possible)
         * 3. New mileage > last mileage: Accept directly (normal case)
         */

        if (doesDatabaseExist(requireContext()) && currentUser != null) {
            // Check mileage validation before saving
            if (finalCurrentMileage < lastMileage) {
                new androidx.appcompat.app.AlertDialog.Builder(requireContext())
                        .setTitle("Mileage Warning")
                        .setMessage("The mileage you entered (" + finalCurrentMileage +
                                ") is smaller than the last record (" + lastMileage + ").\n\n" +
                                "Are you sure?\nLowering mileage is against the law! \uD83D\uDE01")
                        // Insert anyway if user confirms
                        .setPositiveButton("Yes", (d, w) -> insertRefillToDatabase(
                                timestamp, station, finalCurrentMileage, finalCostPerGallon, finalTotalCost))
                        // Cancel if user says no
                        .setNegativeButton("No", null)
                        .show();
                return; // Wait for user decision
            } else if (finalCurrentMileage == lastMileage) {
                new androidx.appcompat.app.AlertDialog.Builder(requireContext())
                        .setTitle("Mileage Warning")
                        .setMessage("The mileage you entered (" + finalCurrentMileage +
                                ") is equal to the last record (" + lastMileage + ").\n\n" +
                                "Are you sure?")
                        .setPositiveButton("Yes", (d, w) -> insertRefillToDatabase(
                                timestamp, station, finalCurrentMileage, finalCostPerGallon, finalTotalCost))
                        .setNegativeButton("No", null)
                        .show();
                return; // Wait for user decision
            }

            // If mileage is valid (greater than last), insert directly
            insertRefillToDatabase(timestamp, station, finalCurrentMileage, finalCostPerGallon, finalTotalCost);
        } else {
            Log.d(TAG, "Database not ready or user not set - data not saved");

            // Show detailed preview since data isn't being persisted
            Toast.makeText(getContext(),
                    "⚠️ Not saved - database not created yet or user not set\n\n" +
                            "Entered data:\n" +
                            "Timestamp: " + timestamp + "\n" +
                            "Gas Station: " + station + "\n" +
                            "Mileage: " + finalCurrentMileage + "\n" +
                            "Cost/Gallon: " + currencySymbol + finalCostPerGallon + "\n" +
                            "Total Cost: " + currencySymbol + finalTotalCost,
                    Toast.LENGTH_LONG).show();
        }
    }

    // Helper method to insert refill into database
    private void insertRefillToDatabase(String timestamp, String station, int mileage,
                                        float costPerGallon, float totalCost) {
        AppDatabase db = DatabaseClient.getInstance(requireContext());
        FuelRefillDao dao = db.fuelRefillDao();
        FuelRefill refill = new FuelRefill(
                currentUser.getId(),
                currentUser.getUsername(),
                timestamp,
                station,
                mileage,
                costPerGallon,
                totalCost
        );

        // Insert refill on background thread
        new Thread(() -> {
            dao.insertRefill(refill);

            // After successful save, update MPG calculation and check alerts
            if (getActivity() instanceof MainActivity) {
                requireActivity().runOnUiThread(() -> ((MainActivity) getActivity()).updateMPGCalculation());
            }

            // Small delay to ensure MPG is calculated before checking alerts
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                Log.e(TAG, "Sleep interrupted", e);
            }

            // Check if MPG alerts should be triggered
            SettingsFragment.checkMPGAlerts(requireContext());

            Log.d(TAG, "Saved refill to database and updated MPG for user: " + currentUser.getUsername());
        }).start();

        Toast.makeText(getContext(), "✅ Saved to database!", Toast.LENGTH_SHORT).show();
    }

    /* Database Lifecycle:
     * - Created when user first registers/logs in
     * - Stored in app's private storage: /data/data/gcz.fueltracker/databases/fueltracker.db
     * - Check prevents crashes if database hasn't been created yet
     */

    // Check if database file exists
    private boolean doesDatabaseExist(Context context) {
        File dbFile = context.getDatabasePath(DB_NAME);
        return dbFile.exists();
    }

    // Return currency symbol based on currency code
    @SuppressWarnings("DuplicateBranchesInSwitch")
    private String getCurrencySymbol(String code) {
        switch (code) {
            case "USD": return "$";
            case "EUR": return "€";
            case "GBP": return "£";
            case "JPY": return "¥";
            case "CAD": return "C$";
            case "AUD": return "A$";
            case "CHF": return "CHF";
            case "CNY": return "¥";
            default: return "$";
        }
    }

    /* Dynamic Logo System:
     * - Converts brand names to resource names: "shell" → "logo_shell"
     * - Looks up drawable resources at runtime
     * - Falls back to generic logo if specific logo not found
     */

    // Dynamically look up logo drawable resource for gas station brands
    @SuppressWarnings("DiscouragedApi")
    private int getLogoDrawable(String brandValue) {
        if (brandValue == null) return R.drawable.logo_generic;

        // Construct drawable resource name from brand value
        String drawableName = "logo_" + brandValue.toLowerCase().trim();

        // Look up resource ID dynamically
        int resId = getResources().getIdentifier(drawableName, "drawable", requireContext().getPackageName());

        // Use generic logo as fallback
        return resId == 0 ? R.drawable.logo_generic : resId;
    }

    /* Visual Selection:
     * - Uses Android's built-in "selected" state
     * - Button styles should define different appearances for selected vs normal
     * - Maintains single selection state (like radio buttons)
     */

    // Update visual selection state for gas station buttons
    private void setSelected(ImageButton button, String stationValue) {
        // Deselect previously selected button if any
        if (selectedButton != null)
            selectedButton.setSelected(false);

        // Select new button and update state
        button.setSelected(true);
        selectedButton = button;
        selectedStationValue = stationValue;
    }

    // Helper class to simplify TextWatcher implementation
    private abstract static class SimpleTextWatcher implements android.text.TextWatcher {
        @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
        @Override public void onTextChanged(CharSequence s, int start, int before, int count) {}
        @Override public abstract void afterTextChanged(android.text.Editable s);
    }
}