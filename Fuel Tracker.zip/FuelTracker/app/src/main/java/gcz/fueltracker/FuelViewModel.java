package gcz.fueltracker;

import androidx.lifecycle.ViewModel;
import gcz.fueltracker.database.User;

// ViewModel class that survives configuration changes
public class FuelViewModel extends ViewModel {
    // Stores the currently logged-in user
    private User currentUser;

    // Retrieves the current user stored in this ViewModel
    public User getCurrentUser() {
        return currentUser;
    }

    //Stores a User object in this ViewModel for persistence
    public void setCurrentUser(User user) {
        this.currentUser = user;
    }
}